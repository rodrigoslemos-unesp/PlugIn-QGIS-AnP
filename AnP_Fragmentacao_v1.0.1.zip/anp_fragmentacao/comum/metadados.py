# -*- coding: utf-8 -*-
"""AnP — Fragmentação: Metadados e Como_Citar PADRONIZADOS (motor xlsx_writer)."""

VERSAO_SUITE = "1.0"
AUTOR        = "Prof. Dr. Rodrigo Silva Lemos"
INSTITUICAO  = ("Departamento de Geografia e Planejamento Ambiental "
                "(DGPA/IGCE) — Unesp, Câmpus Rio Claro")
GRUPO        = ("Grupo de Pesquisa Planejamento Ambiental e Dinâmicas "
                "da Paisagem (CNPq)")
FOMENTO      = "FAPESP — Auxílio à Pesquisa 2024/20517-2"
REPOSITORIO  = "https://github.com/rodrigoslemos-unesp/PlugIn-QGIS-AnP"
FONTE_DADOS  = ("MapBiomas — Coleção 10 da Série Anual de Mapas de "
                "Cobertura e Uso da Terra do Brasil")

AVISO = (
    "\u26a0 SOFTWARE EM DESENVOLVIMENTO — Este plugin está em fase de testes e "
    "aprimoramento contínuo. Os resultados devem ser conferidos e validados "
    "pelo usuário antes de qualquer uso científico, técnico ou institucional. "
    "O autor e a instituição não se responsabilizam por eventuais erros, "
    "omissões, imprecisões ou uso indevido dos resultados.")

NOTA_CRS = (
    "As métricas de área/borda/núcleo (CA, TCA, CORE, MESH, área, perímetro) "
    "só são válidas em CRS PROJETADO (metros). Em CRS geográfico (graus) os "
    "valores não têm sentido métrico. Rode a Preparação com reprojeção "
    "(ex.: EPSG:31983) antes da análise de fragmentação.")

COMO_CITAR = [
    "COMO CITAR",
    "",
    "Dados (fonte primária):",
    "MAPBIOMAS. Coleção 10 da Série Anual de Mapas de Cobertura e Uso da Terra "
    "do Brasil. São Paulo: MapBiomas, 2025. Disponível em: https://mapbiomas.org.",
    "",
    "Software (produto metodológico):",
    "LEMOS, Rodrigo Silva. AnP — Análise da Paisagem: conjunto de plugins QGIS "
    "para análise de cobertura e uso da terra e fragmentação de paisagens "
    "naturais. Rio Claro: Departamento de Geografia e Planejamento Ambiental, "
    "IGCE — Unesp, 2025. Disponível em: "
    "https://github.com/rodrigoslemos-unesp/PlugIn-QGIS-AnP. "
    "DOI: 10.5281/zenodo.21364767",
    "",
    "Recomenda-se citar as duas fontes: os dados (MapBiomas) e o software (AnP).",
]


def escrever_metadados(wb, titulo_modulo, params=None):
    ws = wb.add_sheet("Metadados")
    ws.set_col_width(1, 24); ws.set_col_width(2, 92)
    ws.write(1, 1, "AnP — Fragmentação da Paisagem", bold=True)
    ws.write(1, 2, f"Estrutura: {titulo_modulo}  ·  v{VERSAO_SUITE}", bold=True)
    ws.write(3, 1, "AVISO", color="FFF3E0", bold=True)
    ws.write(3, 2, AVISO, color="FFF3E0")
    gerais = [("Autor", AUTOR), ("Instituição", INSTITUICAO),
              ("Grupo de pesquisa", GRUPO), ("Fomento", FOMENTO),
              ("Repositório", REPOSITORIO), ("Fonte dos dados", FONTE_DADOS),
              ("Nota sobre CRS/área", NOTA_CRS)]
    r = 5
    ws.write(r, 1, "METADADOS GERAIS", bold=True); r += 1
    for k, v in gerais:
        ws.write(r, 1, k, bold=True); ws.write(r, 2, v); r += 1
    if params:
        r += 1
        ws.write(r, 1, "PARÂMETROS DESTA ANÁLISE", bold=True); r += 1
        for k, v in params:
            ws.write(r, 1, str(k), bold=True)
            ws.write(r, 2, "" if v is None else str(v)); r += 1
    return ws


def escrever_como_citar(wb):
    ws = wb.add_sheet("Como_Citar")
    ws.set_col_width(1, 110)
    for i, txt in enumerate(COMO_CITAR, 1):
        ws.write(i, 1, txt, bold=(i == 1))
    return ws
