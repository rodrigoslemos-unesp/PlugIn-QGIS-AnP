# AnP — Análise da Paisagem: Preparação de Dados
# Versão 1.0
# Prof. Dr. Rodrigo Silva Lemos | DGPA/IGCE — Unesp Rio Claro

def classFactory(iface):
    from .plugin import AnPPreparacaoPlugin
    return AnPPreparacaoPlugin(iface)
