"""AnP — Preparação de Dados v1.0"""
import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon

class AnPPreparacaoPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), 'icon.png'))
        self.action = QAction(
            icon,
            'Preparação de Dados',
            self.iface.mainWindow())
        self.action.setToolTip(
            'AnP — Alinhar, recortar e reprojetar rasters MapBiomas')
        self.action.triggered.connect(self._abrir)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(
            'AnP \u2013 An\u00e1lise da Paisagem', self.action)

    def unload(self):
        self.iface.removePluginMenu(
            'AnP \u2013 An\u00e1lise da Paisagem', self.action)
        self.iface.removeToolBarIcon(self.action)
        del self.action

    def _abrir(self):
        from .dialog import AnPPreparacaoDialog
        if self.dialog is None:
            self.dialog = AnPPreparacaoDialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
