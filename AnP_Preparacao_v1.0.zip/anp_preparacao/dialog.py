"""AnP — Preparação de Dados v1.0 — Interface"""
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QComboBox, QCheckBox,
    QGroupBox, QLineEdit, QFileDialog, QTextEdit,
    QMessageBox, QProgressBar, QFrame, QTableWidget,
    QTableWidgetItem, QHeaderView, QSpinBox, QSizePolicy,
    QScrollArea, QWidget, QSizePolicy)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QPixmap, QFont, QColor
from qgis.gui import QgsMapLayerComboBox
from qgis.core import QgsMapLayerProxyModel


class _Worker(QThread):
    progresso = pyqtSignal(str)
    concluido = pyqtSignal(object)
    erro      = pyqtSignal(str)

    def __init__(self, params):
        super().__init__()
        self._p = params

    def run(self):
        try:
            from .processamento import preparar_rasters
            arquivos = preparar_rasters(
                entradas      = self._p['entradas'],
                shapefile     = self._p['shapefile'],
                pasta_saida   = self._p['pasta_saida'],
                reprojetar    = self._p['reprojetar'],
                epsg_saida    = self._p['epsg_saida'],
                padrao_nome   = self._p['padrao_nome'],
                progresso_fn  = self.progresso.emit,
            )
            self.concluido.emit(arquivos)
        except Exception as e:
            import traceback
            self.erro.emit(str(e) + '\n' + traceback.format_exc())


class AnPPreparacaoDialog(QDialog):

    # SIRGAS 2000 UTM — Brasil (Hemisf. Sul: 18S-25S | Norte: 18N-24N)
    # WGS 84 UTM — uso internacional
    FUSOS = [
        # ── SIRGAS 2000 / UTM — Hemisfério Sul (Brasil) ─────────────────────
        ("SIRGAS 2000 / UTM Zona 18S (EPSG:31978) — extremo oeste AM/AC", 31978),
        ("SIRGAS 2000 / UTM Zona 19S (EPSG:31979) — AC/AM/RO/MT", 31979),
        ("SIRGAS 2000 / UTM Zona 20S (EPSG:31980) — RO/MT/MS", 31980),
        ("SIRGAS 2000 / UTM Zona 21S (EPSG:31981) — MT/MS/GO/MG", 31981),
        ("SIRGAS 2000 / UTM Zona 22S (EPSG:31982) — GO/MG/SP/PR/SC/RS", 31982),
        ("SIRGAS 2000 / UTM Zona 23S (EPSG:31983) — MG/SP/RJ/PR [padrão SP]", 31983),
        ("SIRGAS 2000 / UTM Zona 24S (EPSG:31984) — ES/RJ/BA/SE", 31984),
        ("SIRGAS 2000 / UTM Zona 25S (EPSG:31985) — AL/PE/PB/RN/CE/PI/MA", 31985),
        # ── SIRGAS 2000 / UTM — Hemisfério Norte (Brasil) ───────────────────
        ("SIRGAS 2000 / UTM Zona 18N (EPSG:31972) — AM extremo norte", 31972),
        ("SIRGAS 2000 / UTM Zona 19N (EPSG:31973) — PA/AM norte", 31973),
        ("SIRGAS 2000 / UTM Zona 20N (EPSG:31974) — PA/RR norte", 31974),
        ("SIRGAS 2000 / UTM Zona 21N (EPSG:31975) — PA/AP/RR", 31975),
        ("SIRGAS 2000 / UTM Zona 22N (EPSG:31976) — PA/AP", 31976),
        # ── WGS 84 / UTM — Uso Internacional (América do Sul) ───────────────
        ("WGS 84 / UTM Zona 17S (EPSG:32717) — Peru/Equador/Colômbia", 32717),
        ("WGS 84 / UTM Zona 18S (EPSG:32718) — Peru/Bolivia/Chile", 32718),
        ("WGS 84 / UTM Zona 19S (EPSG:32719) — Bolivia/Chile/Argentina", 32719),
        ("WGS 84 / UTM Zona 20S (EPSG:32720) — Argentina/Chile/Paraguay", 32720),
        ("WGS 84 / UTM Zona 21S (EPSG:32721) — Argentina/Paraguai/Uruguai", 32721),
        ("WGS 84 / UTM Zona 22S (EPSG:32722) — Argentina/Chile/Uruguai", 32722),
        ("WGS 84 / UTM Zona 23S (EPSG:32723) — Brasil/Argentina", 32723),
        ("WGS 84 / UTM Zona 24S (EPSG:32724) — Brasil", 32724),
        ("WGS 84 / UTM Zona 25S (EPSG:32725) — Brasil nordeste", 32725),
        # ── EPSG personalizado ───────────────────────────────────────────────
        ("Outro — informar EPSG manualmente abaixo", 0),
    ]

    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface   = iface
        self._worker = None
        self._pasta_rasters = ""
        self.setWindowTitle('AnP — Preparação de Dados  v1.0')
        self.setMinimumWidth(700)
        self.setMinimumHeight(500)
        self.resize(820, 720)           # tamanho inicial razoável
        self.setSizeGripEnabled(True)   # alça de redimensionamento
        self._build_ui()

    # ── Interface ─────────────────────────────────────────────────────────────

    def _build_ui(self):
        # Layout raiz — header fixo no topo, scroll no meio, botões fixos no fundo
        root = QVBoxLayout(self)
        root.setSpacing(0)
        root.setContentsMargins(0, 0, 0, 0)

        # Header sempre visível (fora do scroll)
        root.addWidget(self._header())

        # Área rolável com todos os blocos de configuração
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        conteudo = QWidget()
        lay_scroll = QVBoxLayout(conteudo)
        lay_scroll.setSpacing(10)
        lay_scroll.setContentsMargins(12, 10, 12, 10)

        lay_scroll.addWidget(self._bloco_pasta())
        lay_scroll.addWidget(self._bloco_tabela())
        lay_scroll.addWidget(self._bloco_shapefile())
        lay_scroll.addWidget(self._bloco_projecao())
        lay_scroll.addWidget(self._bloco_nomenclatura())
        lay_scroll.addWidget(self._bloco_saida())
        lay_scroll.addWidget(self._bloco_log())
        lay_scroll.addStretch()

        scroll.setWidget(conteudo)
        root.addWidget(scroll, 1)   # expande para preencher espaço disponível

        # Barra de botões sempre visível (fora do scroll)
        barra = QWidget()
        barra.setStyleSheet("background:#F5F5F5;border-top:1px solid #CCCCCC;")
        barra_lay = QHBoxLayout(barra)
        barra_lay.setContentsMargins(12, 8, 12, 8)
        for item in self._barra_botoes_items():
            if item == 'stretch':
                barra_lay.addStretch()
            else:
                barra_lay.addWidget(item)
        root.addWidget(barra)

    def _header(self):
        frame = QFrame()
        frame.setStyleSheet(
            "QFrame{background-color:#37474F;border-radius:8px;}")
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 10, 16, 10)
        lay.setSpacing(14)

        logo = os.path.join(os.path.dirname(__file__), 'unesp_logo.png')
        if os.path.exists(logo):
            lbl = QLabel()
            pix = QPixmap(logo).scaledToHeight(60, Qt.SmoothTransformation)
            lbl.setPixmap(pix)
            lbl.setStyleSheet("background:white;border-radius:5px;padding:4px;")
            lbl.setFixedSize(pix.width()+10, 70)
            lay.addWidget(lbl)

        sep = QFrame(); sep.setFrameShape(QFrame.VLine)
        sep.setStyleSheet("color:#546E7A;"); lay.addWidget(sep)

        txt = QVBoxLayout(); txt.setSpacing(3)
        txt.setAlignment(Qt.AlignVCenter)

        t1 = QLabel("AnP — Preparação de Dados")
        t1.setStyleSheet("color:white;font-size:15px;font-weight:bold;"
                         "background:transparent;")
        txt.addWidget(t1)

        div = QFrame(); div.setFrameShape(QFrame.HLine)
        div.setStyleSheet("color:#546E7A;"); txt.addWidget(div)

        t2 = QLabel("Alinhamento de grade  ·  Recorte por shapefile  ·  "
                    "Reprojeção SIRGAS 2000 UTM")
        t2.setStyleSheet("color:#B0BEC5;font-size:10px;font-style:italic;"
                         "background:transparent;")
        txt.addWidget(t2)

        t3 = QLabel("Prof. Dr. Rodrigo Silva Lemos  ·  "
                    "DGPA/IGCE — Unesp Rio Claro  ·  AnP v1.0")
        t3.setStyleSheet("color:#90A4AE;font-size:10px;background:transparent;")
        txt.addWidget(t3)

        lay.addLayout(txt, 1)
        return frame

    def _grp(self, cor="#37474F"):
        return (f"QGroupBox{{font-weight:bold;font-size:11px;"
                f"border:1px solid #CCCCCC;border-radius:5px;"
                f"margin-top:8px;padding-top:4px;}}"
                f"QGroupBox::title{{subcontrol-origin:margin;"
                f"left:8px;padding:0 4px;color:{cor};}}")

    def _bloco_pasta(self):
        grp = QGroupBox("1. Origem dos rasters MapBiomas")
        grp.setStyleSheet(self._grp())
        lay = QVBoxLayout(grp); lay.setSpacing(6)

        # Modo A — camadas já carregadas no projeto QGIS
        self.chk_do_projeto = QCheckBox(
            "Usar camadas raster já carregadas no projeto QGIS")
        self.chk_do_projeto.toggled.connect(self._toggle_modo_origem)
        lay.addWidget(self.chk_do_projeto)

        # Painel projeto
        self.frame_projeto = QFrame()
        fp_lay = QHBoxLayout(self.frame_projeto)
        fp_lay.setContentsMargins(0,0,0,0)
        fp_lay.addWidget(QLabel("Adicionar camada:"))
        self.cb_raster_proj = QgsMapLayerComboBox()
        self.cb_raster_proj.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.cb_raster_proj.setAllowEmptyLayer(True)
        fp_lay.addWidget(self.cb_raster_proj)
        btn_add = QPushButton("+ Adicionar à lista")
        btn_add.clicked.connect(self._adicionar_raster_projeto)
        fp_lay.addWidget(btn_add)
        self.frame_projeto.setVisible(False)
        lay.addWidget(self.frame_projeto)

        # Separador
        sep = QLabel("— ou —")
        self.sep_lbl = sep
        sep.setAlignment(Qt.AlignCenter)
        sep.setStyleSheet("color:#999;font-size:10px;")
        lay.addWidget(sep)

        # Modo B — pasta em disco
        row = QHBoxLayout()
        self.le_pasta_r = QLineEdit()
        self.le_pasta_r.setPlaceholderText(
            "Selecione a pasta onde estão os arquivos .tif do MapBiomas...")
        row.addWidget(self.le_pasta_r)
        btn = QPushButton("..."); btn.setFixedWidth(36)
        btn.clicked.connect(self._escolher_pasta_rasters)
        row.addWidget(btn)
        lay.addLayout(row)
        return grp

    def _toggle_modo_origem(self, on):
        self.frame_projeto.setVisible(on)
        self.sep_lbl.setVisible(not on)
        self.le_pasta_r.setVisible(not on)
        # Limpar tabela ao trocar de modo para evitar mistura de fontes
        if self.tabela.rowCount() > 0:
            resp = QMessageBox.question(
                self, 'AnP — Limpar tabela?',
                'Ao trocar o modo de origem a lista de rasters sera limpa. Deseja continuar?',
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if resp == QMessageBox.Yes:
                self.tabela.setRowCount(0)
                self._log("  Tabela limpa — troca de modo de origem.")
            else:
                # Reverter o checkbox
                self.chk_do_projeto.blockSignals(True)
                self.chk_do_projeto.setChecked(not on)
                self.chk_do_projeto.blockSignals(False)
                self._toggle_modo_origem(not on)

    def _adicionar_raster_projeto(self):
        """Adiciona camada raster do projeto QGIS à tabela."""
        layer = self.cb_raster_proj.currentLayer()
        if not layer:
            return
        path  = layer.source().split('|')[0]
        fname = os.path.basename(path)

        # Verificar duplicata
        for row in range(self.tabela.rowCount()):
            if self.tabela.item(row, 1) and                self.tabela.item(row, 1).text() == fname:
                self._log(f"  Camada já na lista: {fname}")
                return

        row = self.tabela.rowCount()
        self.tabela.insertRow(row)

        chk = QTableWidgetItem()
        chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
        chk.setCheckState(Qt.Checked)
        chk.setData(Qt.UserRole, path)   # guarda path completo
        self.tabela.setItem(row, 0, chk)

        item_f = QTableWidgetItem(fname)
        item_f.setFlags(Qt.ItemIsEnabled)
        item_f.setToolTip(path)
        item_f.setForeground(QColor("#1B5E20"))
        self.tabela.setItem(row, 1, item_f)

        item_a = QTableWidgetItem("")
        item_a.setTextAlignment(Qt.AlignCenter)
        self.tabela.setItem(row, 2, item_a)

        nome_base = os.path.splitext(fname)[0]
        self.tabela.setItem(row, 3, QTableWidgetItem(nome_base))
        self._log(f"  + Adicionado do projeto: {fname}")

    def _escolher_pasta_rasters(self):
        pasta = QFileDialog.getExistingDirectory(
            self, 'Pasta com rasters MapBiomas',
            self.le_pasta_r.text() or os.path.expanduser('~'))
        if pasta:
            self.le_pasta_r.setText(pasta)
            self._pasta_rasters = pasta
            self._popular_tabela(pasta)
            self._detectar_crs_pasta(pasta)

    def _bloco_tabela(self):
        grp = QGroupBox("2. Rasters encontrados — informe o ano de cada imagem")
        grp.setStyleSheet(self._grp())
        lay = QVBoxLayout(grp)

        info = QLabel("Preencha o ano correspondente a cada arquivo. "
                      "Deixe em branco para ignorar o arquivo.")
        info.setStyleSheet("font-size:10px;font-style:italic;color:#555;")
        info.setWordWrap(True)
        lay.addWidget(info)

        self.tabela = QTableWidget(0, 4)
        self.tabela.setHorizontalHeaderLabels(
            ["Incluir", "Arquivo", "Ano", "Nome base (saída)"])
        self.tabela.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.Fixed)
        self.tabela.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.Stretch)
        self.tabela.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.Fixed)
        self.tabela.horizontalHeader().setSectionResizeMode(
            3, QHeaderView.Stretch)
        self.tabela.setColumnWidth(0, 54)
        self.tabela.setColumnWidth(2, 70)
        self.tabela.setMinimumHeight(200)
        self.tabela.setAlternatingRowColors(True)
        lay.addWidget(self.tabela)

        btn_lay = QHBoxLayout()
        btn_all = QPushButton("Marcar todos")
        btn_all.clicked.connect(lambda: self._marcar_todos(True))
        btn_lay.addWidget(btn_all)
        btn_none = QPushButton("Desmarcar todos")
        btn_none.clicked.connect(lambda: self._marcar_todos(False))
        btn_lay.addWidget(btn_none)
        btn_lim = QPushButton("Limpar anos")
        btn_lim.clicked.connect(self._limpar_anos)
        btn_lay.addWidget(btn_lim)
        btn_lay.addStretch()
        lay.addLayout(btn_lay)
        return grp

    def _popular_tabela(self, pasta):
        from .processamento import listar_tifs
        tifs = listar_tifs(pasta)
        self.tabela.setRowCount(0)
        for fname in tifs:
            row = self.tabela.rowCount()
            self.tabela.insertRow(row)

            # Col 0 — checkbox Incluir (marcado por padrão)
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Checked)
            chk.setTextAlignment(Qt.AlignCenter)
            self.tabela.setItem(row, 0, chk)

            # Col 1 — nome do arquivo (não editável)
            item_f = QTableWidgetItem(fname)
            item_f.setFlags(Qt.ItemIsEnabled)
            item_f.setToolTip(os.path.join(pasta, fname))
            self.tabela.setItem(row, 1, item_f)

            # Col 2 — ano (editável)
            item_a = QTableWidgetItem("")
            item_a.setTextAlignment(Qt.AlignCenter)
            self.tabela.setItem(row, 2, item_a)

            # Col 3 — nome base sugerido (editável)
            nome_base = os.path.splitext(fname)[0]
            item_n = QTableWidgetItem(nome_base)
            self.tabela.setItem(row, 3, item_n)

        if tifs:
            self._log(f"  {len(tifs)} arquivo(s) .tif encontrado(s) em {pasta}")
        else:
            self._log(f"  Nenhum arquivo .tif encontrado em {pasta}")

    def _marcar_todos(self, estado):
        """Marca ou desmarca todos os checkboxes da tabela."""
        check = Qt.Checked if estado else Qt.Unchecked
        for row in range(self.tabela.rowCount()):
            self.tabela.item(row, 0).setCheckState(check)

    def _limpar_anos(self):
        for row in range(self.tabela.rowCount()):
            self.tabela.item(row, 2).setText("")

    def _bloco_shapefile(self):
        grp = QGroupBox("3. Shapefile de recorte (área de estudo)")
        grp.setStyleSheet(self._grp())
        g = QGridLayout(grp); g.setSpacing(6)

        # Opção A — camada já carregada no projeto QGIS
        g.addWidget(QLabel("Camada do projeto:"), 0, 0)
        self.cb_shp_projeto = QgsMapLayerComboBox()
        self.cb_shp_projeto.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.cb_shp_projeto.setAllowEmptyLayer(True)
        self.cb_shp_projeto.setCurrentIndex(0)
        self.cb_shp_projeto.layerChanged.connect(self._shp_projeto_mudou)
        g.addWidget(self.cb_shp_projeto, 0, 1, 1, 2)

        # Separador
        sep = QLabel("— ou —")
        sep.setAlignment(Qt.AlignCenter)
        sep.setStyleSheet("color:#999;font-size:10px;")
        g.addWidget(sep, 1, 0, 1, 3)

        # Opção B — arquivo em disco
        g.addWidget(QLabel("Arquivo em disco:"), 2, 0)
        self.le_shp = QLineEdit()
        self.le_shp.setPlaceholderText(
            "Ou selecione um shapefile em disco...")
        self.le_shp.textChanged.connect(self._shp_arquivo_mudou)
        g.addWidget(self.le_shp, 2, 1)
        btn = QPushButton("..."); btn.setFixedWidth(36)
        btn.clicked.connect(self._escolher_shp)
        g.addWidget(btn, 2, 2)

        self.lbl_shp_info = QLabel("")
        self.lbl_shp_info.setStyleSheet(
            "font-size:10px;font-style:italic;color:#555;")
        g.addWidget(self.lbl_shp_info, 3, 0, 1, 3)
        g.setColumnStretch(1, 1)
        return grp

    def _shp_projeto_mudou(self, layer):
        """Ao selecionar camada do projeto, limpa o campo de arquivo."""
        if layer:
            self.le_shp.blockSignals(True)
            self.le_shp.clear()
            self.le_shp.blockSignals(False)
            srs = layer.crs()
            n   = layer.featureCount()
            self.lbl_shp_info.setText(
                f"{n} feição(ões)  ·  CRS: {srs.description()}  "
                f"·  [camada do projeto]")

    def _shp_arquivo_mudou(self, path):
        """Ao digitar/selecionar arquivo, limpa a camada do projeto."""
        if path:
            self.cb_shp_projeto.blockSignals(True)
            self.cb_shp_projeto.setCurrentIndex(0)  # vazio
            self.cb_shp_projeto.blockSignals(False)

    def _escolher_shp(self):
        path, _ = QFileDialog.getOpenFileName(
            self, 'Shapefile de recorte', '',
            'Shapefiles (*.shp);;GeoPackage (*.gpkg);;Todos (*)')
        if path:
            self.le_shp.setText(path)
            try:
                from osgeo import ogr
                ds  = ogr.Open(path)
                lyr = ds.GetLayer(0)
                n   = lyr.GetFeatureCount()
                srs = lyr.GetSpatialRef()
                nome_srs = srs.GetName() if srs else "CRS desconhecido"
                self.lbl_shp_info.setText(
                    f"{n} feição(ões)  ·  CRS: {nome_srs}  ·  [arquivo em disco]")
                ds = None
            except Exception:
                pass

    def _shapefile_ativo(self):
        """Retorna o caminho do shapefile ativo (projeto ou disco)."""
        # Prioridade: arquivo em disco se preenchido
        arq = self.le_shp.text().strip()
        if arq and os.path.exists(arq):
            return arq
        # Senão: camada do projeto
        layer = self.cb_shp_projeto.currentLayer()
        if layer:
            return layer.source().split('|')[0]
        return None

    def _bloco_projecao(self):
        grp = QGroupBox("4. Projeção de saída")
        grp.setStyleSheet(self._grp())
        lay = QVBoxLayout(grp); lay.setSpacing(6)

        # Aviso CRS detectado
        self.lbl_crs_orig = QLabel(
            "ℹ  Selecione os rasters para detectar o CRS automaticamente.")
        self.lbl_crs_orig.setStyleSheet(
            "font-size:10px;color:#37474F;font-style:italic;")
        self.lbl_crs_orig.setWordWrap(True)
        lay.addWidget(self.lbl_crs_orig)

        # Checkbox reprojetar
        row = QHBoxLayout()
        self.chk_reproj = QCheckBox(
            "Reprojetar para SIRGAS 2000 / UTM (recomendado para dados não projetados)")
        self.chk_reproj.setChecked(False)
        self.chk_reproj.toggled.connect(self._toggle_reproj)
        row.addWidget(self.chk_reproj)
        row.addStretch()
        lay.addLayout(row)

        # Seletor de fuso
        row2 = QHBoxLayout()
        self.lbl_fuso = QLabel("Fuso UTM:")
        self.lbl_fuso.setEnabled(False)
        row2.addWidget(self.lbl_fuso)
        self.cb_fuso = QComboBox()
        for nome, _ in self.FUSOS:
            self.cb_fuso.addItem(nome)
        # Selecionar 23S como padrão por EPSG (não por índice — lista pode mudar)
        for idx, (nome, epsg) in enumerate(self.FUSOS):
            if epsg == 31983:
                self.cb_fuso.setCurrentIndex(idx)
                break
        self.cb_fuso.currentIndexChanged.connect(self._toggle_epsg_manual)

        # Campo EPSG manual (visível apenas quando "Outro" selecionado)
        row3 = QHBoxLayout()
        self.lbl_epsg = QLabel("EPSG manual:")
        self.lbl_epsg.setVisible(False)
        row3.addWidget(self.lbl_epsg)
        self.le_epsg = QLineEdit()
        self.le_epsg.setPlaceholderText("Ex: 32633")
        self.le_epsg.setFixedWidth(100)
        self.le_epsg.setVisible(False)
        row3.addWidget(self.le_epsg)
        row3.addStretch()
        lay.addLayout(row3)
        self.cb_fuso.setEnabled(False)
        row2.addWidget(self.cb_fuso)
        row2.addStretch()
        lay.addLayout(row2)
        return grp

    def _toggle_reproj(self, on):
        self.lbl_fuso.setEnabled(on)
        self.cb_fuso.setEnabled(on)

    def _detectar_crs_pasta(self, pasta):
        """Detecta CRS do primeiro TIF da pasta e atualiza o aviso."""
        from .processamento import listar_tifs, detectar_crs_raster
        tifs = listar_tifs(pasta)
        if not tifs:
            return
        try:
            info = detectar_crs_raster(os.path.join(pasta, tifs[0]))
            if info['is_projected']:
                msg = (f"✓ CRS detectado: {info['nome_crs']} "
                       f"(EPSG:{info['epsg']}) — já projetado. "
                       f"Reprojeção opcional.")
                self.chk_reproj.setChecked(False)
            else:
                msg = (f"⚠ CRS detectado: {info['nome_crs']} "
                       f"(EPSG:{info['epsg'] or 'desconhecido'}) — "
                       f"coordenadas geográficas. "
                       f"Recomenda-se reprojetar para SIRGAS UTM.")
                self.chk_reproj.setChecked(True)
            self.lbl_crs_orig.setText(msg)
        except Exception as e:
            self.lbl_crs_orig.setText(f"⚠ Não foi possível detectar CRS: {e}")

    def _toggle_epsg_manual(self, idx):
        visivel = (self.FUSOS[idx][1] == 0)
        self.lbl_epsg.setVisible(visivel)
        self.le_epsg.setVisible(visivel)

    def _bloco_nomenclatura(self):
        grp = QGroupBox("5. Padrão de nomenclatura dos arquivos de saída")
        grp.setStyleSheet(self._grp())
        g = QGridLayout(grp); g.setSpacing(6)

        g.addWidget(QLabel("Padrão:"), 0, 0)
        self.le_padrao = QLineEdit("{ANO}_{NOME}")
        self.le_padrao.setToolTip(
            "{ANO} = ano da imagem  |  {NOME} = nome base definido na tabela")
        g.addWidget(self.le_padrao, 0, 1)

        info = QLabel("Variáveis disponíveis:  "
                      "<b>{ANO}</b> = ano da imagem  ·  "
                      "<b>{NOME}</b> = nome base definido na tabela  ·  "
                      "Extensão .tif adicionada automaticamente.")
        info.setStyleSheet("font-size:10px;color:#555;")
        info.setWordWrap(True)
        g.addWidget(info, 1, 0, 1, 3)

        g.addWidget(QLabel("Exemplo:"), 2, 0)
        self.lbl_exemplo = QLabel("")
        self.lbl_exemplo.setStyleSheet(
            "font-family:Courier New;font-size:10px;color:#1B5E20;")
        g.addWidget(self.lbl_exemplo, 2, 1)

        self.le_padrao.textChanged.connect(self._atualizar_exemplo)
        g.setColumnStretch(1, 1)
        self._atualizar_exemplo()
        return grp

    def _atualizar_exemplo(self):
        padrao = self.le_padrao.text()
        ex = (padrao
              .replace('{ANO}', '1985')
              .replace('{NOME}', 'CerradoSP'))
        if not ex.endswith('.tif'):
            ex += '.tif'
        self.lbl_exemplo.setText(f"→  {ex}")

    def _bloco_saida(self):
        grp = QGroupBox("6. Pasta de saída")
        grp.setStyleSheet(self._grp())
        lay = QHBoxLayout(grp); lay.setSpacing(6)
        self.le_saida = QLineEdit()
        self.le_saida.setPlaceholderText(
            "Pasta onde os rasters preparados serão salvos...")
        lay.addWidget(self.le_saida)
        btn = QPushButton("..."); btn.setFixedWidth(36)
        btn.clicked.connect(self._escolher_saida)
        lay.addWidget(btn)
        return grp

    def _escolher_saida(self):
        p = QFileDialog.getExistingDirectory(
            self, 'Pasta de saída',
            self.le_saida.text() or os.path.expanduser('~'))
        if p:
            self.le_saida.setText(p)

    def _bloco_log(self):
        grp = QGroupBox("Log de processamento")
        grp.setStyleSheet(self._grp())
        lay = QVBoxLayout(grp)
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMinimumHeight(100)
        self.log_box.setFont(QFont("Courier New", 9))
        lay.addWidget(self.log_box)
        self.prog_bar = QProgressBar()
        self.prog_bar.setRange(0, 0)
        self.prog_bar.setVisible(False)
        lay.addWidget(self.prog_bar)
        return grp

    def _barra_botoes_items(self):
        """Retorna lista de widgets e 'stretch' para montar a barra de botões."""
        btn_l = QPushButton("Limpar log")
        btn_l.clicked.connect(self.log_box.clear)
        btn_f = QPushButton("Fechar")
        btn_f.clicked.connect(self.close)
        self.btn_exec = QPushButton("▶  Preparar Rasters")
        self.btn_exec.setDefault(True)
        self.btn_exec.setStyleSheet(
            "QPushButton{background:#37474F;color:white;font-weight:bold;"
            "padding:8px 24px;border-radius:5px;}"
            "QPushButton:hover{background:#455A64;}"
            "QPushButton:disabled{background:#AAAAAA;}")
        self.btn_exec.clicked.connect(self._executar)
        return [btn_l, 'stretch', btn_f, self.btn_exec]

    def _barra_botoes(self):
        lay = QHBoxLayout()
        for item in self._barra_botoes_items():
            if item == 'stretch':
                lay.addStretch()
            else:
                lay.addWidget(item)
        return lay

    # ── Lógica ────────────────────────────────────────────────────────────────

    def _log(self, msg):
        self.log_box.append(msg)
        self.log_box.verticalScrollBar().setValue(
            self.log_box.verticalScrollBar().maximum())

    def _coletar_entradas(self):
        """
        Coleta os dados da tabela respeitando checkbox e ano preenchido.
        Suporta rasters do projeto (path em UserRole) e de pasta em disco.
        """
        pasta    = self.le_pasta_r.text().strip()
        entradas = []
        erros    = []

        for row in range(self.tabela.rowCount()):
            chk = self.tabela.item(row, 0)
            if chk and chk.checkState() != Qt.Checked:
                continue

            fname = self.tabela.item(row, 1).text()
            ano_t = self.tabela.item(row, 2).text().strip()
            nome  = self.tabela.item(row, 3).text().strip()

            if not ano_t:
                continue

            try:
                ano = int(ano_t)
            except ValueError:
                erros.append(
                    f"Linha {row+1} ({fname}): '{ano_t}' não é um ano válido.")
                continue

            if not nome:
                nome = os.path.splitext(fname)[0]

            # Path completo: prioriza UserRole (camada do projeto)
            path_completo = chk.data(Qt.UserRole)
            if not path_completo:
                path_completo = os.path.join(pasta, fname)

            entradas.append({
                'path'     : path_completo,
                'ano'      : ano,
                'nome_base': nome,
            })

        return entradas, erros

    def _validar(self):
        erros = []

        # Pasta só é obrigatória se NÃO estiver usando camadas do projeto
        modo_projeto = self.chk_do_projeto.isChecked()
        if not modo_projeto and not self.le_pasta_r.text().strip():
            erros.append("Selecione a pasta com os rasters "
                         "ou use camadas já carregadas no projeto.")

        if not self._shapefile_ativo():
            erros.append("Selecione o shapefile de recorte "
                         "(camada do projeto ou arquivo em disco).")
        if not self.le_saida.text().strip():
            erros.append("Selecione a pasta de saída.")
        if not self.le_padrao.text().strip():
            erros.append("Defina o padrão de nomenclatura.")

        entradas, erros_tab = self._coletar_entradas()
        erros.extend(erros_tab)

        if not entradas:
            erros.append(
                "Nenhum raster marcado com ano preenchido na tabela.")

        return erros, entradas

    def _executar(self):
        erros, entradas = self._validar()
        if erros:
            QMessageBox.warning(self, 'AnP — Campos incompletos',
                                '\n'.join(f'• {e}' for e in erros))
            return

        # Detectar CRS e atualizar aviso se ainda não foi feito
        if self._pasta_rasters:
            self._detectar_crs_pasta(self._pasta_rasters)

        fuso_idx = self.cb_fuso.currentIndex()
        epsg_out = self.FUSOS[fuso_idx][1]
        if epsg_out == 0:  # "Outro — EPSG manual"
            try:
                epsg_out = int(self.le_epsg.text().strip())
            except ValueError:
                QMessageBox.warning(
                    self, 'AnP — EPSG inválido',
                    'Informe um código EPSG válido no campo de EPSG manual.')
                return

        params = {
            'entradas'    : entradas,
            'shapefile'   : self._shapefile_ativo(),
            'pasta_saida' : self.le_saida.text().strip(),
            'reprojetar'  : self.chk_reproj.isChecked(),
            'epsg_saida'  : epsg_out,
            'padrao_nome' : self.le_padrao.text().strip(),
        }

        self.btn_exec.setEnabled(False)
        self.prog_bar.setVisible(True)
        self.log_box.clear()
        self._log(f"Iniciando preparação de {len(entradas)} raster(s)...")
        self._log(f"  Grade de referência: {sorted(entradas, key=lambda x: x['ano'])[0]['ano']}")
        self._log(f"  Padrão de nome: {params['padrao_nome']}")
        if params['reprojetar']:
            self._log(f"  Reprojetando para EPSG:{epsg_out}")

        self._worker = _Worker(params)
        self._worker.progresso.connect(self._log)
        self._worker.concluido.connect(self._concluido)
        self._worker.erro.connect(self._erro)
        self._worker.start()

    def _concluido(self, arquivos):
        self.prog_bar.setVisible(False)
        self.btn_exec.setEnabled(True)
        self._log(f"\n✓ Preparação concluída — {len(arquivos)} arquivo(s) gerado(s):")
        for a in arquivos:
            self._log(f"  → {os.path.basename(a)}")

        resp = QMessageBox.question(
            self, 'AnP — Concluído',
            f'{len(arquivos)} raster(s) preparado(s) com sucesso!\n\n'
            + '\n'.join(os.path.basename(a) for a in arquivos)
            + '\n\nAbrir a pasta de saída?',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)

        if resp == QMessageBox.Yes:
            import subprocess, sys
            pasta = os.path.dirname(arquivos[0])
            if sys.platform == 'win32':
                os.startfile(pasta)
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', pasta])
            else:
                subprocess.Popen(['xdg-open', pasta])

    def _erro(self, msg):
        self.prog_bar.setVisible(False)
        self.btn_exec.setEnabled(True)
        self._log(f"\n⚠ ERRO:\n{msg}")
        QMessageBox.critical(self, 'AnP — Erro', msg[:400])
