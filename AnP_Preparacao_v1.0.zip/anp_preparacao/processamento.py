"""
AnP — Preparação de Dados v1.0
Alinhamento de grade, recorte por shapefile e reprojeção.
"""
import os
import numpy as np
from qgis.core import QgsMessageLog, Qgis

LOG = 'AnP-Prep'

def log(msg, level=Qgis.Info):
    QgsMessageLog.logMessage(str(msg), LOG, level)


# ── Detecção de CRS ───────────────────────────────────────────────────────────

def detectar_crs_raster(path):
    """
    Retorna dict com:
      is_projected : bool
      epsg         : int ou None
      nome_crs     : str
      resolucao_m  : float (se projetado) ou None
    """
    from osgeo import gdal, osr
    ds  = gdal.Open(path)
    if ds is None:
        raise RuntimeError(f"Não foi possível abrir: {path}")
    gt  = ds.GetGeoTransform()
    prj = ds.GetProjection()
    ds  = None

    srs = osr.SpatialReference()
    srs.ImportFromWkt(prj)
    is_proj = bool(srs.IsProjected())

    # Tentar obter EPSG
    srs.AutoIdentifyEPSG()
    epsg = srs.GetAuthorityCode(None)
    try:
        epsg = int(epsg)
    except (TypeError, ValueError):
        epsg = None

    nome = srs.GetName() or "Desconhecido"
    res  = abs(gt[1]) if is_proj else None

    return {
        'is_projected' : is_proj,
        'epsg'         : epsg,
        'nome_crs'     : nome,
        'resolucao_m'  : res,
        'gt'           : gt,
    }


# ── Alinhamento de grade ───────────────────────────────────────────────────────

def obter_info_grade(path):
    """Retorna (gt, proj, cols, rows) do raster."""
    from osgeo import gdal
    ds   = gdal.Open(path)
    if ds is None:
        raise RuntimeError(f"Não foi possível abrir: {path}")
    gt   = ds.GetGeoTransform()
    proj = ds.GetProjection()
    cols = ds.RasterXSize
    rows = ds.RasterYSize
    ds   = None
    return gt, proj, cols, rows


def grades_identicas(gt1, shape1, gt2, shape2, tol=1e-6):
    if shape1 != shape2:
        return False
    for i in range(6):
        if abs(gt1[i] - gt2[i]) > tol:
            return False
    return True


# ── Processamento principal ────────────────────────────────────────────────────

def preparar_rasters(entradas, shapefile, pasta_saida,
                     reprojetar=False, epsg_saida=31983,
                     padrao_nome="{ANO}_{NOME}",
                     progresso_fn=None):
    """
    Fluxo principal de preparação.

    Parâmetros:
      entradas     : lista de dicts {'path': str, 'ano': int, 'nome_base': str}
      shapefile    : caminho do shapefile de recorte
      pasta_saida  : pasta onde os TIFs preparados serão salvos
      reprojetar   : bool — reprojetar para SIRGAS UTM
      epsg_saida   : int — EPSG de saída (padrão 31983 = SIRGAS 2000 / UTM 23S)
      padrao_nome  : str com {ANO} e {NOME} como variáveis
      progresso_fn : callable para log na interface

    Retorna lista de arquivos gerados.
    """
    from osgeo import gdal, ogr

    def prog(msg):
        log(msg)
        if progresso_fn: progresso_fn(msg)

    if not entradas:
        raise ValueError("Nenhum raster fornecido.")

    os.makedirs(pasta_saida, exist_ok=True)

    # ── Raster de referência (primeiro da lista, ordenado por ano) ────────────
    entradas_ord = sorted(entradas, key=lambda x: x['ano'])
    ref = entradas_ord[0]

    prog(f"Raster de referência: {ref['ano']} — {os.path.basename(ref['path'])}")
    gt_ref, proj_ref, cols_ref, rows_ref = obter_info_grade(ref['path'])

    xmin_ref = gt_ref[0]
    ymax_ref = gt_ref[3]
    xres_ref = gt_ref[1]
    yres_ref = abs(gt_ref[5])
    xmax_ref = xmin_ref + xres_ref * cols_ref
    ymin_ref = ymax_ref - yres_ref * rows_ref

    # ── Verificar shapefile ───────────────────────────────────────────────────
    ds_vec = ogr.Open(shapefile)
    if ds_vec is None:
        raise RuntimeError(f"Não foi possível abrir shapefile: {shapefile}")
    lyr_vec = ds_vec.GetLayer(0)
    srs_vec = lyr_vec.GetSpatialRef()
    ds_vec  = None

    # ── Processar cada raster ─────────────────────────────────────────────────
    arquivos_gerados = []

    for i, entrada in enumerate(entradas_ord):
        ano       = entrada['ano']
        path_orig = entrada['path']
        nome_base = entrada['nome_base']

        # Gerar nome do arquivo de saída
        nome_saida = (padrao_nome
                      .replace('{ANO}',  str(ano))
                      .replace('{NOME}', nome_base))
        if not nome_saida.endswith('.tif'):
            nome_saida += '.tif'
        path_saida = os.path.join(pasta_saida, nome_saida)

        prog(f"\n[{i+1}/{len(entradas_ord)}] {ano} — {os.path.basename(path_orig)}")
        prog(f"  → Saída: {nome_saida}")

        # Definir CRS de saída
        if reprojetar:
            dst_srs = f"EPSG:{epsg_saida}"
            prog(f"  → Reprojetando para EPSG:{epsg_saida}")
        else:
            dst_srs = proj_ref

        # ── Callback de progresso GDAL ─────────────────────────────────────────
        # Reporta a cada 10% para evitar a impressão de travamento
        last_pct = [0]
        def gdal_prog(complete, message, cb_data):
            pct = int(complete * 100)
            if pct >= last_pct[0] + 10:
                last_pct[0] = pct
                prog(f"    ... {pct}% concluído")
            return 1

        # ── Operação única: alinhar + recortar no mesmo Warp ─────────────────
        # Mais preciso: pixels de borda passam por UMA ÚNICA operação de
        # vizinho mais próximo. Dois Warps em sequência introduziriam
        # duplo deslocamento nos pixels de borda.
        # O GDAL aplica internamente a cutline e o snap de grade juntos.
        prog(f"  Alinhando grade e recortando (operação única)...")
        prog(f"  [Processamento pode levar minutos para rasters grandes]")
        last_pct[0] = 0

        warp_opts = dict(
            format          = 'GTiff',
            cutlineDSName   = shapefile,
            cropToCutline   = True,
            dstSRS          = dst_srs,
            resampleAlg     = gdal.GRA_NearestNeighbour,
            outputType      = gdal.GDT_Int32,
            creationOptions = ['COMPRESS=LZW', 'TILED=YES'],
            dstNodata       = 0,
            callback        = gdal_prog,
        )

        # Para anos além da referência: forçar snap à grade do raster 1
        if i > 0:
            gt_check    = obter_info_grade(path_orig)[0]
            shape_check = (obter_info_grade(path_orig)[3],
                           obter_info_grade(path_orig)[2])
            if not grades_identicas(gt_ref, (rows_ref, cols_ref),
                                    gt_check, shape_check):
                prog(f"  Grade divergente — aplicando snap à referência ({ref['ano']})...")
                warp_opts['outputBounds'] = (xmin_ref, ymin_ref,
                                             xmax_ref, ymax_ref)
                warp_opts['width']  = cols_ref
                warp_opts['height'] = rows_ref

        resultado = gdal.Warp(path_saida, path_orig, **warp_opts)

        if resultado is None:
            prog(f"  ⚠ Falha ao processar {ano}.")
            continue

        resultado.FlushCache()
        resultado = None

        tamanho = os.path.getsize(path_saida) / (1024*1024)
        prog(f"  ✓ Salvo: {nome_saida} ({tamanho:.1f} MB)")
        arquivos_gerados.append(path_saida)

    return arquivos_gerados


def listar_tifs(pasta):
    """Lista todos os arquivos .tif/.tiff numa pasta."""
    exts = {'.tif', '.tiff', '.TIF', '.TIFF'}
    return sorted([
        f for f in os.listdir(pasta)
        if os.path.splitext(f)[1] in exts
    ])
