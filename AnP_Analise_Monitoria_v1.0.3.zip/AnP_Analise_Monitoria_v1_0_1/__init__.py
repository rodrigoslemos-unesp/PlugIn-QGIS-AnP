# AnP — Análise e Monitoria da Paisagem (plugin integrado)
# Preparação + Monitoria + Relatório  ·  v1.0
# Prof. Dr. Rodrigo Silva Lemos | DGPA/IGCE — Unesp Rio Claro


def classFactory(iface):
    from .plugin import AnPIntegradoPlugin
    return AnPIntegradoPlugin(iface)
