"""
AnP — Recorte e Relatório de Rasters v1.0
Processamento com LEITURA EM JANELA (windowed read).

Nunca carrega o raster inteiro na memória.
Para cada feição, lê apenas a porção do raster que cobre
o bounding box da geometria — viabilizando rasters grandes
como os mosaicos estaduais do MapBiomas.
"""
import os
import numpy as np
from qgis.core import QgsMessageLog, Qgis

LOG = 'AnP-Relatorio'

def log(msg, level=Qgis.Info):
    QgsMessageLog.logMessage(str(msg), LOG, level)


# ── Abertura lazy do raster (sem ReadAsArray) ─────────────────────────────────

def abrir_raster_ds(path):
    """
    Abre o raster e retorna o dataset GDAL sem ler os dados.
    A leitura é feita por janela em recortar_janela().
    """
    from osgeo import gdal
    ds = gdal.Open(path)
    if ds is None:
        raise RuntimeError(f"Não foi possível abrir: {path}")
    gt   = ds.GetGeoTransform()
    proj = ds.GetProjection()
    nd   = ds.GetRasterBand(1).GetNoDataValue()
    px_m = abs(gt[1])
    return ds, gt, proj, nd, px_m


def info_raster(path):
    """Retorna informações básicas sem abrir o dataset inteiro."""
    from osgeo import gdal, osr
    ds = gdal.Open(path)
    if ds is None:
        raise RuntimeError(f"Não foi possível abrir: {path}")
    gt   = ds.GetGeoTransform()
    cols = ds.RasterXSize
    rows = ds.RasterYSize
    px_m = abs(gt[1])
    nd   = ds.GetRasterBand(1).GetNoDataValue()
    proj = ds.GetProjection()
    ds   = None

    srs = osr.SpatialReference()
    srs.ImportFromWkt(proj)
    is_proj = bool(srs.IsProjected())

    return gt, cols, rows, px_m, nd, is_proj


def detectar_pixel_ha(path, pixel_m_manual=None):
    """
    Retorna (px_ha, aviso) para o raster.
    Se CRS geográfico e pixel_m_manual fornecido: usa o valor manual.
    Se CRS geográfico e sem valor manual: retorna (None, mensagem de erro).
    Se CRS projetado: calcula da resolução real.
    """
    from osgeo import gdal, osr
    ds = gdal.Open(path)
    if ds is None:
        raise RuntimeError(f"Não foi possível abrir: {path}")
    gt   = ds.GetGeoTransform()
    proj = ds.GetProjection()
    ds   = None

    srs = osr.SpatialReference()
    srs.ImportFromWkt(proj)
    is_proj = bool(srs.IsProjected())

    if is_proj:
        px_m  = abs(gt[1])
        px_ha = (px_m ** 2) / 10000.0
        return px_ha, None
    else:
        if pixel_m_manual and pixel_m_manual > 0:
            px_ha = (pixel_m_manual ** 2) / 10000.0
            aviso = (f"Raster em coordenadas geograficas (graus). "
                     f"Area calculada com pixel de {pixel_m_manual}m "
                     f"({pixel_m_manual**2} m2 = {px_ha:.6f} ha).")
            return px_ha, aviso
        else:
            return None, "ERRO_CRS_GEOGRAFICO"


# ── Leitura em janela + máscara por geometria ────────────────────────────────

def recortar_janela(ds, gt, geom, crs_wkt, como_float=False):
    """
    Lê APENAS a janela do raster que cobre o bounding box da geometria,
    depois aplica máscara binária pela geometria real (não só pelo bbox).

    Reprojetar automaticamente a geometria para o CRS do raster se
    os dois sistemas de coordenadas forem diferentes — evita o erro
    "Feição sem sobreposição" causado por incompatibilidade de CRS.
    """
    from osgeo import gdal, ogr, osr

    cols_tot = ds.RasterXSize
    rows_tot = ds.RasterYSize

    g = geom.Clone()
    if not g.IsValid():
        g = g.MakeValid()

    # ── Verificar e alinhar CRS ──────────────────────────────────────────────
    srs_raster = osr.SpatialReference()
    srs_raster.ImportFromWkt(ds.GetProjection())
    srs_raster.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)

    srs_vec = osr.SpatialReference()
    srs_vec.ImportFromWkt(crs_wkt)
    srs_vec.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)

    # Se os CRS forem diferentes, reprojetar geometria para o CRS do raster
    if not srs_raster.IsSame(srs_vec):
        transform = osr.CoordinateTransformation(srs_vec, srs_raster)
        g_proj = g.Clone()
        g_proj.Transform(transform)
        g_para_janela = g_proj     # geometria reprojetada para calcular janela
        crs_wkt_mask  = ds.GetProjection()  # máscara no CRS do raster
    else:
        g_para_janela = g
        crs_wkt_mask  = crs_wkt

    env = g_para_janela.GetEnvelope()   # minX, maxX, minY, maxY

    # Converter extensão → índices de pixel
    px0 = max(0, int((env[0] - gt[0]) / gt[1]))
    px1 = min(cols_tot, int((env[1] - gt[0]) / gt[1]) + 2)
    py0 = max(0, int((env[3] - gt[3]) / gt[5]))
    py1 = min(cols_tot, int((env[2] - gt[3]) / gt[5]) + 2)
    py1 = min(rows_tot, int((env[2] - gt[3]) / gt[5]) + 2)

    if px0 >= px1 or py0 >= py1:
        raise ValueError(
            f"Feicao sem sobreposicao com o raster. "
            f"CRS raster: {srs_raster.GetName()} | "
            f"CRS shapefile: {srs_vec.GetName()} | "
            f"Envelope reprojetado: {env}")

    w = px1 - px0
    h = py1 - py0

    # ── Ler APENAS a janela ──────────────────────────────────────────────────
    band = ds.GetRasterBand(1)
    sub  = band.ReadAsArray(px0, py0, w, h)   # lê só o recorte!
    if sub is None:
        raise ValueError("Falha na leitura da janela do raster.")

    gt_sub = (
        gt[0] + px0 * gt[1],   # nova origem X
        gt[1], gt[2],
        gt[3] + py0 * gt[5],   # nova origem Y
        gt[4], gt[5]
    )

    # ── Rasterizar máscara da geometria no mesmo bbox ────────────────────────
    mem_drv = gdal.GetDriverByName('MEM')
    mds = mem_drv.Create('', w, h, 1, gdal.GDT_Byte)
    mds.SetGeoTransform(gt_sub)
    mds.SetProjection(ds.GetProjection())
    mds.GetRasterBand(1).Fill(0)

    vds = ogr.GetDriverByName('Memory').CreateDataSource('')
    srs = osr.SpatialReference()
    srs.ImportFromWkt(crs_wkt_mask)   # CRS já alinhado ao raster
    lyr = vds.CreateLayer('', srs=srs)
    ft  = ogr.Feature(lyr.GetLayerDefn())
    ft.SetGeometry(g_para_janela)     # geometria reprojetada
    lyr.CreateFeature(ft)

    gdal.RasterizeLayer(mds, [1], lyr, burn_values=[1])
    mds.FlushCache()
    mask = mds.GetRasterBand(1).ReadAsArray()
    mds = vds = None

    # ── Aplicar máscara ──────────────────────────────────────────────────────
    if como_float:
        sub_out = sub.astype(np.float32)
        sub_out[mask == 0] = np.nan
    else:
        sub_out = sub.astype(np.int32)
        sub_out[mask == 0] = -1

    return sub_out, gt_sub


# ── Salvar raster de saída ────────────────────────────────────────────────────

def salvar_raster(arr, gt, proj, path, nd=0, dtype=None):
    from osgeo import gdal
    dtype = dtype or gdal.GDT_Int32
    rows, cols = arr.shape
    drv = gdal.GetDriverByName('GTiff')
    ds  = drv.Create(path, cols, rows, 1, dtype,
                     options=['COMPRESS=LZW', 'TILED=YES'])
    ds.SetGeoTransform(gt); ds.SetProjection(proj)
    b = ds.GetRasterBand(1)
    b.SetNoDataValue(nd)
    b.WriteArray(arr); b.FlushCache()
    ds = None


# ── MODO 1: MapBiomas ─────────────────────────────────────────────────────────

def processar_mapbiomas(raster_path, shapefile, campo_id,
                         nivel_legenda, unidade,
                         gerar_tif, pasta_saida,
                         pixel_m_manual=None,
                         progresso_fn=None):
    """
    Lê o raster MapBiomas por janela para cada feição.
    Nunca carrega o raster inteiro na memória.
    """
    from osgeo import ogr
    from .legenda import (agregar_nivel, LEGENDA_NIVEL,
                          GRUPOS, CLASSES_EXCLUIR)

    def prog(msg):
        log(msg); progresso_fn and progresso_fn(msg)

    gt, cols_tot, rows_tot, px_m, nd, is_proj = info_raster(raster_path)
    px_ha, aviso_crs = detectar_pixel_ha(raster_path, pixel_m_manual)
    if px_ha is None:
        raise RuntimeError(
            "O raster esta em coordenadas geograficas (graus, nao metros). "
            "Informe o tamanho do pixel em metros (ex: 30 para Landsat) "
            "ou reprojetar o raster para SIRGAS 2000 / UTM antes de processar.")
    if aviso_crs:
        prog(f"  {aviso_crs}")
    fator  = 1.0 if unidade == 'ha' else 0.01
    leg    = LEGENDA_NIVEL.get(nivel_legenda, LEGENDA_NIVEL[2])
    excluir = set(CLASSES_EXCLUIR)
    if nd is not None:
        excluir.add(int(nd))

    prog(f"Raster: {cols_tot} x {rows_tot} px | pixel={px_m}m | "
         f"leitura por janela (sem carregar o raster inteiro)")

    # Abrir dataset (mantido aberto durante todo o loop)
    ds, gt, proj, nd, px_m = abrir_raster_ds(raster_path)

    ds_vec = ogr.Open(shapefile)
    lyr    = ds_vec.GetLayer(0)
    crs_wkt = lyr.GetSpatialRef().ExportToWkt() \
              if lyr.GetSpatialRef() else proj
    n_feats = lyr.GetFeatureCount()

    resultados = []

    for i, feat in enumerate(lyr):
        nome = str(feat.GetField(campo_id))[:60]
        geom = feat.GetGeometryRef()
        if geom is None:
            continue
        prog(f"[{i+1}/{n_feats}] {nome}...")

        try:
            sub_int, gt_sub = recortar_janela(
                ds, gt, geom.Clone(), crs_wkt, como_float=False)
        except Exception as e:
            prog(f"  ⚠ {nome}: {e}")
            continue

        # Agregar ao nível solicitado (só na janela)
        sub_agg = agregar_nivel(
            np.where(sub_int < 0, 0, sub_int), nivel_legenda)
        sub_agg[sub_int < 0] = -1   # restaurar máscara

        # Contar pixels por classe
        validos = sub_agg[sub_agg > 0]
        validos = validos[~np.isin(validos, list(excluir))]
        tot = len(validos) or 1

        for cls in np.unique(validos):
            cls_i = int(cls)
            n     = int(np.sum(validos == cls_i))
            resultados.append({
                'feicao'    : nome,
                'grupo'     : GRUPOS.get(cls_i, 'Outros'),
                'cod_classe': cls_i,
                'classe'    : leg.get(cls_i, f'Código {cls_i}'),
                f'area_{unidade}': round(n * px_ha * fator, 4),
                'percentual': round(n / tot, 6),
            })

        # Salvar TIF da feição (já é a janela — não o raster inteiro)
        if gerar_tif and pasta_saida:
            nome_arq = f"{nome.replace(' ','_')}_N{nivel_legenda}.tif"
            arr_out  = np.where(sub_int < 0, 0, sub_agg).astype(np.int32)
            salvar_raster(arr_out, gt_sub, proj, os.path.join(pasta_saida, nome_arq))
            prog(f"  ✓ TIF: {nome_arq}")

    ds = None   # fechar dataset
    lyr.ResetReading(); ds_vec = None
    return resultados


# ── MODO 2: Raster Genérico ───────────────────────────────────────────────────

def reclassificar(arr_float, intervalos):
    """Reclassifica array contínuo com NaN já marcado."""
    arr_out = np.zeros(arr_float.shape, dtype=np.int32)
    mapa    = {}
    for idx, inv in enumerate(intervalos, 1):
        vmin = float(inv['min'])
        vmax = float(inv['max'])
        mask = (~np.isnan(arr_float)) & (arr_float >= vmin) & (arr_float < vmax)
        arr_out[mask] = idx
        mapa[idx] = inv['nome']
    return arr_out, mapa


def processar_generico(raster_path, shapefile, campo_id,
                        intervalos, calc_zonal,
                        gerar_tif, pasta_saida,
                        pixel_m_manual=None,
                        progresso_fn=None):
    from osgeo import ogr

    def prog(msg):
        log(msg); progresso_fn and progresso_fn(msg)

    gt, cols_tot, rows_tot, px_m, nd, is_proj = info_raster(raster_path)
    px_ha, aviso_crs = detectar_pixel_ha(raster_path, pixel_m_manual)
    if px_ha is None:
        raise RuntimeError(
            "O raster esta em coordenadas geograficas (graus, nao metros). "
            "Informe o tamanho do pixel em metros ou reprojetar o raster.")
    if aviso_crs:
        prog(f"  {aviso_crs}")

    prog(f"Raster: {cols_tot} x {rows_tot} px | pixel={px_m}m | "
         f"leitura por janela")

    ds, gt, proj, nd, px_m = abrir_raster_ds(raster_path)

    ds_vec = ogr.Open(shapefile)
    lyr    = ds_vec.GetLayer(0)
    crs_wkt = lyr.GetSpatialRef().ExportToWkt() \
              if lyr.GetSpatialRef() else proj
    n_feats = lyr.GetFeatureCount()

    res_area = []; res_zon = []

    for i, feat in enumerate(lyr):
        nome = str(feat.GetField(campo_id))[:60]
        geom = feat.GetGeometryRef()
        if geom is None:
            continue
        prog(f"[{i+1}/{n_feats}] {nome}...")

        try:
            sub_f, gt_sub = recortar_janela(
                ds, gt, geom.Clone(), crs_wkt, como_float=True)
        except Exception as e:
            prog(f"  ⚠ {nome}: {e}")
            continue

        # Aplicar nodata adicional
        if nd is not None:
            sub_f[sub_f == nd] = np.nan

        # Estatísticas zonais
        if calc_zonal:
            vals = sub_f[~np.isnan(sub_f)]
            if len(vals) > 0:
                res_zon.append({
                    'feicao'       : nome,
                    'n_pixels'     : int(len(vals)),
                    'media'        : round(float(np.mean(vals)), 6),
                    'desvio_padrao': round(float(np.std(vals)), 6),
                    'minimo'       : round(float(np.nanmin(vals)), 6),
                    'maximo'       : round(float(np.nanmax(vals)), 6),
                    'mediana'      : round(float(np.median(vals)), 6),
                })

        # Reclassificação e área
        arr_cls, mapa = reclassificar(sub_f, intervalos)
        tot = int(np.sum(arr_cls > 0)) or 1
        for cod, nome_cls in mapa.items():
            n = int(np.sum(arr_cls == cod))
            if n == 0:
                continue
            inv = intervalos[cod-1]
            res_area.append({
                'feicao'    : nome,
                'cod_classe': cod,
                'classe'    : nome_cls,
                'intervalo' : f"[{inv['min']}, {inv['max']}[",
                'area_ha'   : round(n * px_ha, 4),
                'percentual': round(n / tot, 6),
            })

        if gerar_tif and pasta_saida:
            nome_arq = f"{nome.replace(' ','_')}_reclassificado.tif"
            salvar_raster(arr_cls, gt_sub, proj,
                          os.path.join(pasta_saida, nome_arq))
            prog(f"  ✓ TIF: {nome_arq}")

    ds = None
    lyr.ResetReading(); ds_vec = None
    return res_area, res_zon


def salvar_reclassificado_global(raster_path, intervalos,
                                  path_saida, progresso_fn=None):
    """
    Reclassifica o raster completo em blocos (block-by-block)
    para evitar estouro de memória.
    """
    from osgeo import gdal

    def prog(msg):
        if progresso_fn: progresso_fn(msg)

    ds_in  = gdal.Open(raster_path)
    gt     = ds_in.GetGeoTransform()
    proj   = ds_in.GetProjection()
    cols   = ds_in.RasterXSize
    rows   = ds_in.RasterYSize
    nd     = ds_in.GetRasterBand(1).GetNoDataValue()
    band   = ds_in.GetRasterBand(1)

    drv    = gdal.GetDriverByName('GTiff')
    ds_out = drv.Create(path_saida, cols, rows, 1, gdal.GDT_Int32,
                        options=['COMPRESS=LZW', 'TILED=YES'])
    ds_out.SetGeoTransform(gt); ds_out.SetProjection(proj)
    b_out  = ds_out.GetRasterBand(1)
    b_out.SetNoDataValue(0)

    BLOCO = 2048   # processar em blocos de 2048 linhas
    n_blocos = (rows + BLOCO - 1) // BLOCO

    for bi in range(n_blocos):
        y0   = bi * BLOCO
        h    = min(BLOCO, rows - y0)
        arr  = band.ReadAsArray(0, y0, cols, h).astype(np.float32)
        if nd is not None:
            arr[arr == nd] = np.nan
        arr_cls, _ = reclassificar(arr, intervalos)
        b_out.WriteArray(arr_cls, 0, y0)
        pct = int((bi+1)/n_blocos*100)
        if pct % 20 == 0:
            prog(f"    ... {pct}%")

    b_out.FlushCache(); ds_in = ds_out = None
    prog(f"  ✓ Raster global: {os.path.basename(path_saida)}")
