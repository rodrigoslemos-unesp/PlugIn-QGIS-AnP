# AnP — Análise da Paisagem: Recorte e Relatório de Rasters
# Versão 1.0
# Prof. Dr. Rodrigo Silva Lemos | DGPA/IGCE — Unesp Rio Claro

def classFactory(iface):
    from .plugin import AnPRelatorioPlugin
    return AnPRelatorioPlugin(iface)
