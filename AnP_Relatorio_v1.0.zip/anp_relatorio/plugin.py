"""AnP — Recorte e Relatório de Rasters v1.0"""
import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon

class AnPRelatorioPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), 'icon.png'))
        self.action = QAction(
            icon,
            'Recorte e Relatório de Rasters',
            self.iface.mainWindow())
        self.action.setToolTip(
            'AnP — Recortar rasters por feições e gerar relatórios tabulares')
        self.action.triggered.connect(self._abrir)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(
            'AnP \u2013 An\u00e1lise da Paisagem', self.action)

    def unload(self):
        self.iface.removePluginMenu(
            'AnP \u2013 An\u00e1lise da Paisagem', self.action)
        self.iface.removeToolBarIcon(self.action)
        del self.action

    def _abrir(self):
        from .dialog import AnPRelatorioDialog
        if self.dialog is None:
            self.dialog = AnPRelatorioDialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
