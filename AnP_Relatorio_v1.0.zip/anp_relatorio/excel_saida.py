"""
AnP Relatório — Geração de planilhas Excel.
Saída: ANO_base_relatorio.xlsx com abas por modo.
"""
import os
from .xlsx_writer import XlsxBook

CRED = ("AnP v1.0 — Recorte e Relatório de Rasters  |  "
        "Prof. Dr. Rodrigo Silva Lemos  |  DGPA/IGCE — Unesp Rio Claro  |  "
        "rodrigo.s.lemos@unesp.br")

COR_A = "F5F5F5"; COR_B = "FFFFFF"
COR_POS = "C8E6C9"; COR_NEG = "FFCCBC"; COR_NEU = "E3F2FD"


def _hdr(ws, col, texto, largura):
    ws.write(1, col, texto, header=True)
    ws.set_col_width(col, largura)


# ── Aba cobertura MapBiomas ───────────────────────────────────────────────────

def _aba_cobertura(wb, resultados, unidade, nivel):
    ws   = wb.add_sheet("Cobertura")
    ul   = 'ha' if unidade == 'ha' else 'km2'
    hdrs = [("feicao",30),("grupo",22),("cod_classe",11),
            ("classe",30),(f"area_{ul}",14),("percentual",12)]
    for col, (h, w) in enumerate(hdrs, 1):
        _hdr(ws, col, h, w)
    ws.set_row_height(1, 26)

    row = 2
    for i, d in enumerate(resultados):
        shade = COR_A if i % 2 == 0 else COR_B
        ws.write(row, 1, d['feicao'],         color=shade)
        ws.write(row, 2, d.get('grupo',''),   color=shade)
        ws.write(row, 3, d['cod_classe'],      color=shade)
        ws.write(row, 4, d['classe'],          color=shade)
        ws.write(row, 5, d.get(f'area_{ul}',0),
                 color=shade, num_fmt='num')
        ws.write(row, 6, d['percentual'],
                 color=shade, num_fmt='pct')
        row += 1

    ws.write(row+1, 1, f"Legenda MapBiomas Coleção 10 — Nível {nivel}  |  {CRED}")


# ── Aba área por classe (modo genérico) ──────────────────────────────────────

def _aba_classes(wb, resultados, intervalos):
    ws   = wb.add_sheet("Classes")
    hdrs = [("feicao",30),("cod_classe",11),("classe",28),
            ("intervalo",18),("area_ha",14),("percentual",12)]
    for col, (h, w) in enumerate(hdrs, 1):
        _hdr(ws, col, h, w)
    ws.set_row_height(1, 26)

    # Cores por classe (do usuário)
    cores = {i+1: inv.get('cor','F5F5F5').lstrip('#')
             for i, inv in enumerate(intervalos)}

    row = 2
    for d in resultados:
        shade = cores.get(d['cod_classe'], COR_A)
        ws.write(row, 1, d['feicao'],    color=shade)
        ws.write(row, 2, d['cod_classe'],color=shade)
        ws.write(row, 3, d['classe'],    color=shade)
        ws.write(row, 4, d['intervalo'], color=shade)
        ws.write(row, 5, d['area_ha'],   color=shade, num_fmt='num')
        ws.write(row, 6, d['percentual'],color=shade, num_fmt='pct')
        row += 1
    ws.write(row+1, 1, CRED)


# ── Aba estatísticas zonais ───────────────────────────────────────────────────

def _aba_zonais(wb, resultados):
    ws   = wb.add_sheet("Estatisticas_Zonais")
    hdrs = [("feicao",30),("n_pixels",12),("media",14),
            ("desvio_padrao",16),("minimo",14),("maximo",14),("mediana",14)]
    for col, (h, w) in enumerate(hdrs, 1):
        _hdr(ws, col, h, w)
    ws.set_row_height(1, 26)

    row = 2
    for i, d in enumerate(resultados):
        shade = COR_A if i % 2 == 0 else COR_B
        ws.write(row, 1, d['feicao'],       color=shade)
        ws.write(row, 2, d['n_pixels'],     color=shade)
        ws.write(row, 3, d['media'],        color=shade, num_fmt='num')
        ws.write(row, 4, d['desvio_padrao'],color=shade, num_fmt='num')
        ws.write(row, 5, d['minimo'],       color=shade, num_fmt='num')
        ws.write(row, 6, d['maximo'],       color=shade, num_fmt='num')
        ws.write(row, 7, d['mediana'],      color=shade, num_fmt='num')
        row += 1
    ws.write(row+1, 1, CRED)


# ── Aba de reclassificação (documentação metodológica) ───────────────────────

def _aba_reclassificacao(wb, intervalos, nome_raster):
    ws   = wb.add_sheet("Reclassificacao")
    hdrs = [("codigo",10),("nome_classe",30),("valor_minimo",16),
            ("valor_maximo",16),("cor",12)]
    for col, (h, w) in enumerate(hdrs, 1):
        _hdr(ws, col, h, w)
    ws.set_row_height(1, 26)

    ws.write(1, 6, f"Raster: {nome_raster}", header=True)

    row = 2
    for i, inv in enumerate(intervalos, 1):
        shade = inv.get('cor','F5F5F5').lstrip('#')
        ws.write(row, 1, i,             color=shade)
        ws.write(row, 2, inv['nome'],   color=shade)
        ws.write(row, 3, float(inv['min']), color=shade, num_fmt='num')
        ws.write(row, 4, float(inv['max']), color=shade, num_fmt='num')
        ws.write(row, 5, inv.get('cor',''), color=shade)
        row += 1
    ws.write(row+1, 1, CRED)


# ── Exportação principal ──────────────────────────────────────────────────────

def exportar_mapbiomas(resultados, pasta, nome_base, unidade, nivel,
                        progresso_fn=None):
    def prog(msg):
        if progresso_fn: progresso_fn(msg)
    wb = XlsxBook()
    _aba_cobertura(wb, resultados, unidade, nivel)
    p  = os.path.join(pasta, f"{nome_base}_relatorio.xlsx")
    wb.save(p)
    prog(f"  ✓ {os.path.basename(p)}")
    return p


def exportar_generico(res_area, res_zonais, intervalos,
                       pasta, nome_base, nome_raster,
                       progresso_fn=None):
    def prog(msg):
        if progresso_fn: progresso_fn(msg)
    wb = XlsxBook()
    _aba_classes(wb, res_area, intervalos)
    if res_zonais:
        _aba_zonais(wb, res_zonais)
    _aba_reclassificacao(wb, intervalos, nome_raster)
    p  = os.path.join(pasta, f"{nome_base}_relatorio.xlsx")
    wb.save(p)
    prog(f"  ✓ {os.path.basename(p)}")
    return p
