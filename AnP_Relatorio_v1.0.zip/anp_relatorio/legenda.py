"""
AnP Relatório — Legenda MapBiomas Coleção 10.
Hierarquia de 4 níveis para agregação por análise.
"""

CLASSES_EXCLUIR = {0, 255, -1, 27}
CLASSES_NATURAIS = {3,4,5,6,49,11,12,32,29,50,13,33,31}

HIERARQUIA = {
    1:{'l1':1,'l2':1,'l3':1,'l4':1},    10:{'l1':10,'l2':10,'l3':10,'l4':10},
    14:{'l1':14,'l2':14,'l3':14,'l4':14},22:{'l1':22,'l2':22,'l3':22,'l4':22},
    26:{'l1':26,'l2':26,'l3':26,'l4':26},27:{'l1':27,'l2':27,'l3':27,'l4':27},
    3:{'l1':1,'l2':3,'l3':3,'l4':3},    4:{'l1':1,'l2':4,'l3':4,'l4':4},
    5:{'l1':1,'l2':5,'l3':5,'l4':5},    6:{'l1':1,'l2':6,'l3':6,'l4':6},
    49:{'l1':1,'l2':49,'l3':49,'l4':49},11:{'l1':10,'l2':11,'l3':11,'l4':11},
    12:{'l1':10,'l2':12,'l3':12,'l4':12},32:{'l1':10,'l2':32,'l3':32,'l4':32},
    29:{'l1':10,'l2':29,'l3':29,'l4':29},50:{'l1':10,'l2':50,'l3':50,'l4':50},
    15:{'l1':14,'l2':15,'l3':15,'l4':15},18:{'l1':14,'l2':18,'l3':18,'l4':18},
    9:{'l1':14,'l2':9,'l3':9,'l4':9},   21:{'l1':14,'l2':21,'l3':21,'l4':21},
    23:{'l1':22,'l2':23,'l3':23,'l4':23},24:{'l1':22,'l2':24,'l3':24,'l4':24},
    30:{'l1':22,'l2':30,'l3':30,'l4':30},75:{'l1':22,'l2':75,'l3':75,'l4':75},
    25:{'l1':22,'l2':25,'l3':25,'l4':25},33:{'l1':26,'l2':33,'l3':33,'l4':33},
    31:{'l1':26,'l2':31,'l3':31,'l4':31},19:{'l1':14,'l2':18,'l3':19,'l4':19},
    36:{'l1':14,'l2':18,'l3':36,'l4':36},39:{'l1':14,'l2':18,'l3':19,'l4':39},
    20:{'l1':14,'l2':18,'l3':19,'l4':20},40:{'l1':14,'l2':18,'l3':19,'l4':40},
    62:{'l1':14,'l2':18,'l3':19,'l4':62},41:{'l1':14,'l2':18,'l3':19,'l4':41},
    46:{'l1':14,'l2':18,'l3':36,'l4':46},47:{'l1':14,'l2':18,'l3':36,'l4':47},
    35:{'l1':14,'l2':18,'l3':36,'l4':35},48:{'l1':14,'l2':18,'l3':36,'l4':48},
}

LEGENDA_NIVEL = {
    1:{1:"Floresta",10:"Veg. Herbácea e Arbustiva",14:"Agropecuária",
       22:"Área não Vegetada",26:"Corpo D'água",27:"Não Observado"},
    2:{1:"Floresta",10:"Veg. Herbácea e Arbustiva",14:"Agropecuária",
       22:"Área não Vegetada",26:"Corpo D'água",27:"Não Observado",
       3:"Formação Florestal",4:"Formação Savânica",5:"Mangue",
       6:"Floresta Alagável",49:"Restinga Arbórea",
       11:"Campo Alagado e Área Pantanosa",12:"Formação Campestre",
       32:"Apicum",29:"Afloramento Rochoso",50:"Restinga Herbácea",
       15:"Pastagem",18:"Agricultura",9:"Silvicultura",21:"Mosaico de Usos",
       23:"Praia, Duna e Areal",24:"Área Urbanizada",30:"Mineração",
       75:"Usina Fotovoltaica (beta)",25:"Outras Áreas não Vegetadas",
       33:"Rio, Lago e Oceano",31:"Aquicultura"},
}
LEGENDA_NIVEL[3] = {**LEGENDA_NIVEL[2],
    19:"Lavoura Temporária",36:"Lavoura Perene"}
LEGENDA_NIVEL[4] = {**LEGENDA_NIVEL[3],
    39:"Soja",20:"Cana-de-açúcar",40:"Arroz",62:"Algodão (beta)",
    41:"Outras Lavouras Temporárias",46:"Café",47:"Citrus",
    35:"Dendê",48:"Outras Lavouras Perenes"}

GRUPOS = {
    3:"Floresta",4:"Floresta",5:"Floresta",6:"Floresta",49:"Floresta",
    11:"Veg. Herbácea e Aquática",12:"Veg. Herbácea e Aquática",
    32:"Veg. Herbácea e Aquática",29:"Veg. Herbácea e Aquática",
    50:"Veg. Herbácea e Aquática",
    15:"Agropecuária",18:"Agropecuária",19:"Agropecuária",36:"Agropecuária",
    39:"Agropecuária",20:"Agropecuária",40:"Agropecuária",62:"Agropecuária",
    41:"Agropecuária",46:"Agropecuária",47:"Agropecuária",35:"Agropecuária",
    48:"Agropecuária",9:"Agropecuária",21:"Agropecuária",
    23:"Área não Vegetada",24:"Área não Vegetada",30:"Área não Vegetada",
    75:"Área não Vegetada",25:"Área não Vegetada",
    33:"Corpo D'água",31:"Corpo D'água",
}

def agregar_nivel(arr, nivel):
    import numpy as np
    chave = f'l{nivel}'
    resultado = arr.copy()
    for cod, info in HIERARQUIA.items():
        resultado[arr == cod] = info[chave]
    return resultado

def descricao_nivel(nivel):
    n = len({v[f'l{nivel}'] for v in HIERARQUIA.values()
             if v[f'l{nivel}'] not in CLASSES_EXCLUIR})
    ex = {1:"Floresta, Agropecuária…",2:"Form. Florestal, Pastagem…",
          3:"Lavoura Temporária, Lavoura Perene",4:"Soja, Cana, Café…"}
    return f"Nível {nivel} — {n} classes  |  {ex.get(nivel,'')}"
