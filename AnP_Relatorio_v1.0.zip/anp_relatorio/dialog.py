"""AnP — Recorte e Relatório de Rasters v1.0 — Interface"""
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QComboBox, QCheckBox,
    QGroupBox, QLineEdit, QFileDialog, QTextEdit,
    QMessageBox, QProgressBar, QFrame, QTableWidget,
    QTableWidgetItem, QHeaderView, QTabWidget, QWidget,
    QScrollArea, QSizePolicy, QDoubleSpinBox, QColorDialog,
    QAbstractItemView)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QPixmap, QFont, QColor
from qgis.gui import QgsMapLayerComboBox, QgsFieldComboBox
from qgis.core import QgsMapLayerProxyModel


class _Worker(QThread):
    progresso = pyqtSignal(str)
    concluido = pyqtSignal(object)
    erro      = pyqtSignal(str)

    def __init__(self, params):
        super().__init__(); self._p = params

    def run(self):
        try:
            modo = self._p['modo']
            if modo == 'mapbiomas':
                self._run_mapbiomas()
            else:
                self._run_generico()
        except Exception as e:
            import traceback
            self.erro.emit(str(e) + '\n' + traceback.format_exc())

    def _run_mapbiomas(self):
        from .processamento import processar_mapbiomas
        from .excel_saida   import exportar_mapbiomas
        p = self._p
        resultados = processar_mapbiomas(
            raster_path  = p['raster'],
            shapefile    = p['shapefile'],
            campo_id     = p['campo_id'],
            nivel_legenda= p['nivel'],
            pixel_m_manual= p.get('pixel_m'),
            unidade      = p['unidade'],
            gerar_tif    = p['gerar_tif'],
            pasta_saida  = p['pasta'],
            progresso_fn = self.progresso.emit,
        )
        arq = exportar_mapbiomas(
            resultados   = resultados,
            pasta        = p['pasta'],
            nome_base    = p['nome_base'],
            unidade      = p['unidade'],
            nivel        = p['nivel'],
            progresso_fn = self.progresso.emit,
        )
        self.concluido.emit([arq])

    def _run_generico(self):
        from .processamento import (processar_generico,
                                     salvar_reclassificado_global)
        from .excel_saida   import exportar_generico
        p = self._p
        res_area, res_zon = processar_generico(
            raster_path  = p['raster'],
            shapefile    = p['shapefile'],
            campo_id     = p['campo_id'],
            intervalos   = p['intervalos'],
            pixel_m_manual= p.get('pixel_m'),
            calc_zonal   = p['calc_zonal'],
            gerar_tif    = p['gerar_tif'],
            pasta_saida  = p['pasta'],
            progresso_fn = self.progresso.emit,
        )
        arq = exportar_generico(
            res_area     = res_area,
            res_zonais   = res_zon,
            intervalos   = p['intervalos'],
            pixel_m_manual= p.get('pixel_m'),
            pasta        = p['pasta'],
            nome_base    = p['nome_base'],
            nome_raster  = os.path.basename(p['raster']),
            progresso_fn = self.progresso.emit,
        )
        arquivos = [arq]
        if p.get('raster_global'):
            path_r = os.path.join(p['pasta'],
                                  p['nome_base']+'_reclassificado.tif')
            salvar_reclassificado_global(
                p['raster'], p['intervalos'], path_r,
                progresso_fn=self.progresso.emit)
            arquivos.append(path_r)
        self.concluido.emit(arquivos)


class AnPRelatorioDialog(QDialog):

    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface; self._worker = None
        self.setWindowTitle('AnP — Recorte e Relatório de Rasters  v1.0')
        self.setMinimumWidth(800)
        self.setMinimumHeight(520)
        self.resize(860, 700)
        self.setSizeGripEnabled(True)
        self._build_ui()

    # ── Interface ─────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(0); root.setContentsMargins(0,0,0,0)
        root.addWidget(self._header())

        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        conteudo = QWidget()
        lay = QVBoxLayout(conteudo)
        lay.setSpacing(10); lay.setContentsMargins(12,10,12,10)

        # Dados comuns: raster, shapefile, saída
        lay.addWidget(self._bloco_dados_comuns())

        # Abas para os dois modos
        self.tabs = QTabWidget()
        self.tabs.addTab(self._tab_mapbiomas(), "🗺  MapBiomas")
        self.tabs.addTab(self._tab_generico(),  "📊  Raster Genérico")
        lay.addWidget(self.tabs)

        lay.addWidget(self._bloco_saida())
        lay.addWidget(self._bloco_log())
        lay.addStretch()
        scroll.setWidget(conteudo)
        root.addWidget(scroll, 1)

        # Barra de botões fixa
        barra = QWidget()
        barra.setStyleSheet(
            "background:#F5F5F5;border-top:1px solid #CCCCCC;")
        bl = QHBoxLayout(barra)
        bl.setContentsMargins(12,8,12,8)
        btn_l = QPushButton("Limpar log")
        btn_l.clicked.connect(self.log_box.clear)
        bl.addWidget(btn_l); bl.addStretch()
        btn_f = QPushButton("Fechar")
        btn_f.clicked.connect(self.close)
        bl.addWidget(btn_f)
        self.btn_exec = QPushButton("▶  Gerar Relatório")
        self.btn_exec.setDefault(True)
        self.btn_exec.setStyleSheet(
            "QPushButton{background:#1B5E20;color:white;font-weight:bold;"
            "padding:8px 24px;border-radius:5px;}"
            "QPushButton:hover{background:#2E7D32;}"
            "QPushButton:disabled{background:#AAAAAA;}")
        self.btn_exec.clicked.connect(self._executar)
        bl.addWidget(self.btn_exec)
        root.addWidget(barra)

    def _header(self):
        frame = QFrame()
        frame.setStyleSheet(
            "QFrame{background-color:#1B5E20;border-radius:0px;}")
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16,10,16,10); lay.setSpacing(14)
        logo = os.path.join(os.path.dirname(__file__), 'unesp_logo.png')
        if os.path.exists(logo):
            lbl = QLabel()
            pix = QPixmap(logo).scaledToHeight(60, Qt.SmoothTransformation)
            lbl.setPixmap(pix)
            lbl.setStyleSheet("background:white;border-radius:5px;padding:4px;")
            lbl.setFixedSize(pix.width()+10, 70)
            lay.addWidget(lbl)
        sep = QFrame(); sep.setFrameShape(QFrame.VLine)
        sep.setStyleSheet("color:#2E7A3A;"); lay.addWidget(sep)
        txt = QVBoxLayout(); txt.setSpacing(3)
        txt.setAlignment(Qt.AlignVCenter)
        t1 = QLabel("AnP — Recorte e Relatório de Rasters")
        t1.setStyleSheet("color:white;font-size:15px;font-weight:bold;"
                         "background:transparent;")
        txt.addWidget(t1)
        div = QFrame(); div.setFrameShape(QFrame.HLine)
        div.setStyleSheet("color:#2E7A3A;"); txt.addWidget(div)
        t2 = QLabel("Recorte por feições  ·  Relatório de cobertura  ·  "
                    "Reclassificação e estatísticas zonais")
        t2.setStyleSheet("color:#A5D6A7;font-size:10px;font-style:italic;"
                         "background:transparent;")
        txt.addWidget(t2)
        t3 = QLabel("Prof. Dr. Rodrigo Silva Lemos  ·  "
                    "DGPA/IGCE — Unesp Rio Claro  ·  AnP v1.0")
        t3.setStyleSheet("color:#81C784;font-size:10px;background:transparent;")
        txt.addWidget(t3)
        lay.addLayout(txt, 1)
        return frame

    def _grp(self):
        return ("QGroupBox{font-weight:bold;font-size:11px;"
                "border:1px solid #CCCCCC;border-radius:5px;"
                "margin-top:8px;padding-top:4px;}"
                "QGroupBox::title{subcontrol-origin:margin;"
                "left:8px;padding:0 4px;}")

    def _bloco_dados_comuns(self):
        grp = QGroupBox("Dados de entrada")
        grp.setStyleSheet(self._grp())
        g = QGridLayout(grp); g.setSpacing(6)

        # Raster
        g.addWidget(QLabel("Raster:"), 0, 0)
        self.cb_raster = QgsMapLayerComboBox()
        self.cb_raster.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.cb_raster.setAllowEmptyLayer(True)
        self.cb_raster.layerChanged.connect(self._verificar_crs_raster)
        g.addWidget(self.cb_raster, 0, 1, 1, 2)
        btn_r = QPushButton("..."); btn_r.setFixedWidth(36)
        btn_r.clicked.connect(self._escolher_raster)
        g.addWidget(btn_r, 0, 3)

        self.le_raster = QLineEdit()
        self.le_raster.setPlaceholderText(
            "Ou caminho do raster em disco...")
        self.le_raster.editingFinished.connect(
            lambda: self._verificar_crs_raster(None))
        g.addWidget(self.le_raster, 1, 1, 1, 3)

        # Shapefile
        g.addWidget(QLabel("Shapefile:"), 2, 0)
        self.cb_shape = QgsMapLayerComboBox()
        self.cb_shape.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.cb_shape.setAllowEmptyLayer(True)
        self.cb_shape.layerChanged.connect(
            lambda lyr: self.cb_campo.setLayer(lyr) if lyr else None)
        g.addWidget(self.cb_shape, 2, 1, 1, 2)
        btn_s = QPushButton("..."); btn_s.setFixedWidth(36)
        btn_s.clicked.connect(self._escolher_shape)
        g.addWidget(btn_s, 2, 3)

        self.le_shape = QLineEdit()
        self.le_shape.setPlaceholderText(
            "Ou caminho do shapefile em disco...")
        g.addWidget(self.le_shape, 3, 1, 1, 3)

        # Aviso CRS + pixel size
        self.frame_crs = QFrame()
        self.frame_crs.setStyleSheet(
            "QFrame{background:#FFF8E1;border:1px solid #F9A825;"
            "border-radius:4px;padding:4px;}")
        crs_lay = QGridLayout(self.frame_crs)
        crs_lay.setContentsMargins(8,4,8,4); crs_lay.setSpacing(4)

        self.lbl_crs_aviso = QLabel(
            "Selecione um raster para verificar o sistema de coordenadas.")
        self.lbl_crs_aviso.setStyleSheet("font-size:10px;color:#555;")
        self.lbl_crs_aviso.setWordWrap(True)
        crs_lay.addWidget(self.lbl_crs_aviso, 0, 0, 1, 4)

        self.lbl_pixel = QLabel("Tamanho do pixel (m):")
        self.lbl_pixel.setStyleSheet("font-size:10px;font-weight:bold;")
        self.lbl_pixel.setVisible(False)
        crs_lay.addWidget(self.lbl_pixel, 1, 0)

        self.cb_pixel_preset = QComboBox()
        self.cb_pixel_preset.addItems([
            "Landsat — 30m",
            "Sentinel-2 — 10m",
            "MODIS — 250m",
            "MODIS — 500m",
            "Outro (informar abaixo)",
        ])
        self.cb_pixel_preset.setVisible(False)
        self.cb_pixel_preset.currentIndexChanged.connect(
            self._atualizar_pixel_manual)
        crs_lay.addWidget(self.cb_pixel_preset, 1, 1)

        self.le_pixel_m = QLineEdit("30")
        self.le_pixel_m.setFixedWidth(70)
        self.le_pixel_m.setPlaceholderText("metros")
        self.le_pixel_m.setVisible(False)
        crs_lay.addWidget(QLabel("m →"), 1, 2)
        crs_lay.addWidget(self.le_pixel_m, 1, 3)

        self.lbl_pixel_ha = QLabel("")
        self.lbl_pixel_ha.setStyleSheet("font-size:10px;color:#1B5E20;")
        self.lbl_pixel_ha.setVisible(False)
        crs_lay.addWidget(self.lbl_pixel_ha, 1, 4)
        self.le_pixel_m.textChanged.connect(self._atualizar_pixel_ha)

        self.frame_crs.setVisible(False)
        g.addWidget(self.frame_crs, 2, 0, 1, 4)

        # Campo identificador
        g.addWidget(QLabel("Campo ID:"), 4, 0)
        self.cb_campo = QgsFieldComboBox()
        self.cb_campo.setLayer(self.cb_shape.currentLayer())
        g.addWidget(self.cb_campo, 4, 1, 1, 3)

        # Nome base
        g.addWidget(QLabel("Nome base:"), 5, 0)
        self.le_nome = QLineEdit("relatorio")
        self.le_nome.setToolTip(
            "Prefixo dos arquivos de saída (ex: CerradoSP_2024)")
        g.addWidget(self.le_nome, 5, 1)
        g.addWidget(QLabel("→ relatorio.xlsx"), 5, 2)
        g.setColumnStretch(1, 1)
        return grp

    def _escolher_raster(self):
        p, _ = QFileDialog.getOpenFileName(
            self, 'Raster', '', 'GeoTIFF (*.tif *.tiff);;Todos (*)')
        if p: self.le_raster.setText(p)

    def _verificar_crs_raster(self, layer=None):
        """Detecta CRS do raster e exibe aviso se necessário."""
        path = self._raster_ativo()
        if not path:
            self.frame_crs.setVisible(False)
            return
        try:
            from .processamento import info_raster
            _, _, _, px_m, _, is_proj = info_raster(path)
            if is_proj:
                self.lbl_crs_aviso.setText(
                    f"OK — Raster projetado. Pixel: {px_m:.2f} m. "
                    f"Area calculada automaticamente.")
                self.lbl_crs_aviso.setStyleSheet(
                    "font-size:10px;color:#1B5E20;")
                self.frame_crs.setStyleSheet(
                    "QFrame{background:#E8F5E9;border:1px solid #4CAF50;"
                    "border-radius:4px;padding:4px;}")
                for w in [self.lbl_pixel, self.cb_pixel_preset,
                          self.le_pixel_m, self.lbl_pixel_ha]:
                    w.setVisible(False)
            else:
                self.lbl_crs_aviso.setText(
                    "ATENCAO: Raster em coordenadas geograficas (graus). "
                    "As areas serao 0 sem informar o tamanho do pixel. "
                    "Selecione o sensor ou informe o pixel em metros.")
                self.lbl_crs_aviso.setStyleSheet(
                    "font-size:10px;color:#BF360C;font-weight:bold;")
                self.frame_crs.setStyleSheet(
                    "QFrame{background:#FFF3E0;border:1px solid #FF6F00;"
                    "border-radius:4px;padding:4px;}")
                for w in [self.lbl_pixel, self.cb_pixel_preset,
                          self.le_pixel_m, self.lbl_pixel_ha]:
                    w.setVisible(True)
                self._atualizar_pixel_ha()
            self.frame_crs.setVisible(True)
        except Exception as e:
            self.lbl_crs_aviso.setText(f"Nao foi possivel verificar CRS: {e}")
            self.frame_crs.setVisible(True)

    def _atualizar_pixel_manual(self, idx):
        presets = {"Landsat":30,"Sentinel":10,"MODIS 250":250,"MODIS 500":500}
        vals = [30, 10, 250, 500, None]
        v = vals[idx] if idx < len(vals) else None
        if v:
            self.le_pixel_m.setText(str(v))
            self.le_pixel_m.setEnabled(False)
        else:
            self.le_pixel_m.setEnabled(True)

    def _atualizar_pixel_ha(self):
        try:
            px = float(self.le_pixel_m.text())
            ha = round((px**2)/10000, 6)
            self.lbl_pixel_ha.setText(f"= {px**2:.0f} m² = {ha:.6f} ha/pixel")
        except ValueError:
            self.lbl_pixel_ha.setText("")

    def _pixel_m_ativo(self):
        """Retorna o tamanho do pixel em metros configurado pelo usuário."""
        try:
            return float(self.le_pixel_m.text())
        except ValueError:
            return None

    def _escolher_shape(self):
        p, _ = QFileDialog.getOpenFileName(
            self, 'Shapefile', '',
            'Shapefiles (*.shp);;GeoPackage (*.gpkg);;Todos (*)')
        if p: self.le_shape.setText(p)

    # ── Tab MapBiomas ──────────────────────────────────────────────────────────

    def _tab_mapbiomas(self):
        w = QWidget(); lay = QVBoxLayout(w); lay.setSpacing(8)

        info = QLabel("Aplica a legenda hierárquica da Coleção 10 do MapBiomas. "
                      "Calcula área por classe de cobertura para cada feição do shapefile.")
        info.setStyleSheet("font-size:10px;color:#555;font-style:italic;")
        info.setWordWrap(True); lay.addWidget(info)

        grp = QGroupBox("Configurações MapBiomas"); grp.setStyleSheet(self._grp())
        g = QGridLayout(grp); g.setSpacing(8)

        g.addWidget(QLabel("Nível de legenda:"), 0, 0)
        self.cb_nivel = QComboBox()
        from .legenda import descricao_nivel
        for n in range(1, 5):
            self.cb_nivel.addItem(descricao_nivel(n), n)
        self.cb_nivel.setCurrentIndex(1)  # N2 padrão
        g.addWidget(self.cb_nivel, 0, 1, 1, 2)

        g.addWidget(QLabel("Unidade de área:"), 1, 0)
        self.cb_unidade = QComboBox()
        self.cb_unidade.addItems(["Hectares (ha)", "Quilômetros quadrados (km²)"])
        g.addWidget(self.cb_unidade, 1, 1)

        self.chk_tif_mb = QCheckBox(
            "Gerar TIF recortado por feição (com legenda N aplicada)")
        g.addWidget(self.chk_tif_mb, 2, 0, 1, 3)
        g.setColumnStretch(2, 1)
        lay.addWidget(grp); lay.addStretch()
        return w

    # ── Tab Raster Genérico ───────────────────────────────────────────────────

    def _tab_generico(self):
        w = QWidget(); lay = QVBoxLayout(w); lay.setSpacing(8)

        info = QLabel("Para qualquer raster contínuo (NDVI, NDWI, temperatura, "
                      "declividade etc.). Defina intervalos de reclassificação "
                      "e o plugin calculará área por classe e estatísticas zonais.")
        info.setStyleSheet("font-size:10px;color:#555;font-style:italic;")
        info.setWordWrap(True); lay.addWidget(info)

        # Tabela de reclassificação
        grp_cls = QGroupBox("Intervalos de Reclassificação")
        grp_cls.setStyleSheet(self._grp())
        g_cls = QVBoxLayout(grp_cls)

        hdr_info = QLabel(
            "Intervalo fechado à esquerda, aberto à direita: [min, max[  —  "
            "ex: NDVI [0.2, 0.4[ = Vegetação Moderada")
        hdr_info.setStyleSheet("font-size:9px;color:#666;")
        hdr_info.setWordWrap(True)
        g_cls.addWidget(hdr_info)

        self.tbl_cls = QTableWidget(0, 5)
        self.tbl_cls.setHorizontalHeaderLabels(
            ["Cód", "Mínimo", "Máximo", "Nome da Classe", "Cor"])
        self.tbl_cls.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.Fixed)
        self.tbl_cls.horizontalHeader().setSectionResizeMode(
            3, QHeaderView.Stretch)
        self.tbl_cls.horizontalHeader().setSectionResizeMode(
            4, QHeaderView.Fixed)
        self.tbl_cls.setColumnWidth(0, 40)
        self.tbl_cls.setColumnWidth(1, 90)
        self.tbl_cls.setColumnWidth(2, 90)
        self.tbl_cls.setColumnWidth(4, 70)
        self.tbl_cls.setMinimumHeight(150)
        self.tbl_cls.setSelectionBehavior(QAbstractItemView.SelectRows)
        g_cls.addWidget(self.tbl_cls)

        btn_lay = QHBoxLayout()
        btn_add = QPushButton("+ Adicionar classe")
        btn_add.clicked.connect(self._adicionar_classe)
        btn_rem = QPushButton("− Remover selecionada")
        btn_rem.clicked.connect(self._remover_classe)
        btn_lay.addWidget(btn_add); btn_lay.addWidget(btn_rem)
        btn_lay.addStretch()
        g_cls.addLayout(btn_lay)
        lay.addWidget(grp_cls)

        # Opções
        grp_op = QGroupBox("Opções"); grp_op.setStyleSheet(self._grp())
        g_op = QVBoxLayout(grp_op)
        self.chk_zonal = QCheckBox(
            "Calcular estatísticas zonais (média, desvio padrão, mín, máx, mediana)")
        self.chk_zonal.setChecked(True)
        g_op.addWidget(self.chk_zonal)
        self.chk_tif_gen = QCheckBox(
            "Gerar TIF reclassificado por feição")
        g_op.addWidget(self.chk_tif_gen)
        self.chk_tif_global = QCheckBox(
            "Gerar TIF reclassificado para o raster completo")
        g_op.addWidget(self.chk_tif_global)
        lay.addWidget(grp_op)
        lay.addStretch()
        return w

    def _adicionar_classe(self):
        row = self.tbl_cls.rowCount()
        self.tbl_cls.insertRow(row)

        # Cod (não editável)
        cod = QTableWidgetItem(str(row+1))
        cod.setFlags(Qt.ItemIsEnabled)
        cod.setTextAlignment(Qt.AlignCenter)
        self.tbl_cls.setItem(row, 0, cod)

        # Min e Max
        self.tbl_cls.setItem(row, 1, QTableWidgetItem("0.0"))
        self.tbl_cls.setItem(row, 2, QTableWidgetItem("1.0"))

        # Nome
        self.tbl_cls.setItem(row, 3,
            QTableWidgetItem(f"Classe {row+1}"))

        # Botão de cor
        btn_cor = QPushButton()
        cor_hex = self._cor_padrao(row)
        btn_cor.setStyleSheet(
            f"background-color:#{cor_hex};border:1px solid #999;")
        btn_cor.setProperty('cor', cor_hex)
        btn_cor.clicked.connect(
            lambda _, r=row, b=btn_cor: self._escolher_cor(r, b))
        self.tbl_cls.setCellWidget(row, 4, btn_cor)

    def _cor_padrao(self, idx):
        cores = ['388E3C','1976D2','F57C00','9C27B0',
                 'D32F2F','00897B','FDD835','6D4C41',
                 '546E7A','AD1457']
        return cores[idx % len(cores)]

    def _escolher_cor(self, row, btn):
        cor = QColorDialog.getColor(
            QColor(f"#{btn.property('cor')}"), self, "Escolher cor")
        if cor.isValid():
            hex_cor = cor.name().lstrip('#')
            btn.setStyleSheet(
                f"background-color:#{hex_cor};border:1px solid #999;")
            btn.setProperty('cor', hex_cor)

    def _remover_classe(self):
        rows = sorted(set(i.row() for i in
                          self.tbl_cls.selectedItems()), reverse=True)
        for r in rows:
            self.tbl_cls.removeRow(r)
        # Atualizar códigos
        for r in range(self.tbl_cls.rowCount()):
            self.tbl_cls.item(r, 0).setText(str(r+1))

    # ── Bloco saída ───────────────────────────────────────────────────────────

    def _bloco_saida(self):
        grp = QGroupBox("Pasta de saída"); grp.setStyleSheet(self._grp())
        lay = QHBoxLayout(grp); lay.setSpacing(6)
        self.le_pasta = QLineEdit()
        self.le_pasta.setPlaceholderText(
            "Pasta onde os arquivos serão salvos...")
        lay.addWidget(self.le_pasta)
        btn = QPushButton("..."); btn.setFixedWidth(36)
        btn.clicked.connect(self._escolher_pasta)
        lay.addWidget(btn)
        return grp

    def _escolher_pasta(self):
        p = QFileDialog.getExistingDirectory(
            self, 'Pasta de saída',
            self.le_pasta.text() or os.path.expanduser('~'))
        if p: self.le_pasta.setText(p)

    def _bloco_log(self):
        grp = QGroupBox("Log"); grp.setStyleSheet(self._grp())
        lay = QVBoxLayout(grp)
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMinimumHeight(100)
        self.log_box.setFont(QFont("Courier New", 9))
        lay.addWidget(self.log_box)
        self.prog_bar = QProgressBar()
        self.prog_bar.setRange(0,0); self.prog_bar.setVisible(False)
        lay.addWidget(self.prog_bar)
        return grp

    # ── Lógica ────────────────────────────────────────────────────────────────

    def _log(self, msg):
        self.log_box.append(msg)
        self.log_box.verticalScrollBar().setValue(
            self.log_box.verticalScrollBar().maximum())

    def _raster_ativo(self):
        arq = self.le_raster.text().strip()
        if arq and os.path.exists(arq):
            return arq
        lyr = self.cb_raster.currentLayer()
        return lyr.source().split('|')[0] if lyr else None

    def _shape_ativo(self):
        arq = self.le_shape.text().strip()
        if arq and os.path.exists(arq):
            return arq
        lyr = self.cb_shape.currentLayer()
        return lyr.source().split('|')[0] if lyr else None

    def _coletar_intervalos(self):
        intervalos = []; erros = []
        for row in range(self.tbl_cls.rowCount()):
            try:
                vmin = float(self.tbl_cls.item(row,1).text())
                vmax = float(self.tbl_cls.item(row,2).text())
                nome = self.tbl_cls.item(row,3).text().strip()
                btn  = self.tbl_cls.cellWidget(row, 4)
                cor  = btn.property('cor') if btn else 'F5F5F5'
                if not nome:
                    erros.append(f"Linha {row+1}: nome da classe vazio.")
                    continue
                if vmin >= vmax:
                    erros.append(
                        f"Linha {row+1}: mínimo ({vmin}) >= máximo ({vmax}).")
                    continue
                intervalos.append({'min':vmin,'max':vmax,
                                   'nome':nome,'cor':f'#{cor}'})
            except (ValueError, AttributeError) as e:
                erros.append(f"Linha {row+1}: {e}")
        return intervalos, erros

    def _validar(self):
        erros = []
        if not self._raster_ativo():
            erros.append("Selecione o raster (camada do projeto ou arquivo).")
        if not self._shape_ativo():
            erros.append("Selecione o shapefile.")
        if not self.cb_campo.currentField():
            erros.append("Selecione o campo identificador das feições.")
        if not self.le_pasta.text().strip():
            erros.append("Selecione a pasta de saída.")
        if not self.le_nome.text().strip():
            erros.append("Informe o nome base dos arquivos de saída.")

        modo = 'generico' if self.tabs.currentIndex() == 1 else 'mapbiomas'
        intervalos = []; erros_cls = []
        if modo == 'generico':
            intervalos, erros_cls = self._coletar_intervalos()
            erros.extend(erros_cls)
            if not intervalos and not erros_cls:
                erros.append("Adicione ao menos um intervalo de reclassificação.")

        return erros, modo, intervalos

    def _executar(self):
        erros, modo, intervalos = self._validar()
        if erros:
            QMessageBox.warning(self, 'AnP — Campos incompletos',
                                '\n'.join(f'• {e}' for e in erros))
            return

        unidade = 'ha' if 'Hectare' in self.cb_unidade.currentText() else 'km2'
        nivel   = self.cb_nivel.itemData(self.cb_nivel.currentIndex()) or 2

        params = {
            'modo'        : modo,
            'raster'      : self._raster_ativo(),
            'shapefile'   : self._shape_ativo(),
            'campo_id'    : self.cb_campo.currentField(),
            'pasta'       : self.le_pasta.text().strip(),
            'nome_base'   : self.le_nome.text().strip(),
            # MapBiomas
            'nivel'       : nivel,
            'unidade'     : unidade,
            'pixel_m'     : self._pixel_m_ativo(),
            'gerar_tif'   : (self.chk_tif_mb.isChecked()
                             if modo == 'mapbiomas'
                             else self.chk_tif_gen.isChecked()),
            # Genérico
            'intervalos'  : intervalos,
            'calc_zonal'  : self.chk_zonal.isChecked(),
            'raster_global': self.chk_tif_global.isChecked(),
        }

        self.btn_exec.setEnabled(False)
        self.prog_bar.setVisible(True)
        self.log_box.clear()
        self._log(f"Modo: {'MapBiomas' if modo == 'mapbiomas' else 'Raster Genérico'}")
        self._log(f"Raster: {os.path.basename(params['raster'])}")

        self._worker = _Worker(params)
        self._worker.progresso.connect(self._log)
        self._worker.concluido.connect(self._concluido)
        self._worker.erro.connect(self._erro)
        self._worker.start()

    def _concluido(self, arquivos):
        self.prog_bar.setVisible(False); self.btn_exec.setEnabled(True)
        self._log(f"\n✓ Concluído — {len(arquivos)} arquivo(s):")
        for a in arquivos:
            self._log(f"  → {a}")

        resp = QMessageBox.question(
            self, 'AnP — Concluído',
            '\n'.join(os.path.basename(a) for a in arquivos)
            + '\n\nAbrir pasta de saída?',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if resp == QMessageBox.Yes:
            import subprocess, sys
            pasta = os.path.dirname(arquivos[0])
            if sys.platform == 'win32': os.startfile(pasta)
            elif sys.platform == 'darwin': subprocess.Popen(['open', pasta])
            else: subprocess.Popen(['xdg-open', pasta])

    def _erro(self, msg):
        self.prog_bar.setVisible(False); self.btn_exec.setEnabled(True)
        self._log(f"\n⚠ ERRO:\n{msg}")
        QMessageBox.critical(self, 'AnP — Erro', msg[:400])
