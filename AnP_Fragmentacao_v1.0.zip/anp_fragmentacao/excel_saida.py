"""
AnP Fragmentação — Geração das planilhas Excel de saída.
Arquivo: ano1_ano2_paisagem.xlsx
Abas tidy: Metricas | Paisagem | Variacoes
"""
import os
from .xlsx_writer import XlsxBook
from .legenda import GRUPOS_TEMATICOS, UNIDADES

CRED = ("AnP v1.0 — Fragmentação e Conectividade da Paisagem  |  "
        "Prof. Dr. Rodrigo Silva Lemos  |  DGPA/IGCE — Unesp Rio Claro  |  "
        "rodrigo.s.lemos@unesp.br")

COR_A = "F5F5F5"
COR_B = "FFFFFF"


def _hdr(ws, col, texto, largura):
    ws.write(1, col, texto, header=True)
    ws.set_col_width(col, largura)


def _aba_metricas(wb, resultado, ano1, ano2):
    """
    Tidy: recorte | grupo | tema | metrica | unidade | ano | valor
    """
    ws   = wb.add_sheet("Metricas")
    hdrs = [("recorte",30),("grupo",28),("tema",16),
            ("metrica",12),("unidade",10),("ano",7),("valor",16)]
    for col, (h, w) in enumerate(hdrs, 1):
        _hdr(ws, col, h, w)
    ws.set_row_height(1, 26)

    row = 2; i = 0
    for rec, dados in resultado.items():
        if not isinstance(dados, dict) or 'grupos' not in dados.get(str(ano1), dados.get(str(ano2), {})):
            continue
        lbl = 'Shape Completo' if rec == '__shape_completo__' else rec
        for ano_k in [str(ano1), str(ano2)]:
            ano_d = dados.get(ano_k, {})
            grupos = ano_d.get('grupos', {})
            for nome_g, metricas in grupos.items():
                for tema, siglas in GRUPOS_TEMATICOS.items():
                    if tema == "Paisagem":
                        continue
                    for sigla in siglas:
                        v = metricas.get(sigla)
                        if v is None:
                            continue
                        shade = COR_A if i % 2 == 0 else COR_B
                        ws.write(row, 1, lbl,                   color=shade)
                        ws.write(row, 2, nome_g,                color=shade)
                        ws.write(row, 3, tema,                  color=shade)
                        ws.write(row, 4, sigla,                 color=shade)
                        ws.write(row, 5, UNIDADES.get(sigla,''),color=shade)
                        ws.write(row, 6, int(ano_k),            color=shade)
                        ws.write(row, 7, v, color=shade,
                                 num_fmt='num' if isinstance(v,float) else None)
                        row += 1; i += 1
    ws.write(row + 1, 1, CRED)


def _aba_paisagem(wb, resultado, ano1, ano2):
    """
    Tidy: recorte | metrica | unidade | ano | valor
    """
    ws   = wb.add_sheet("Paisagem")
    hdrs = [("recorte",30),("metrica",12),("unidade",10),
            ("ano",7),("valor",16)]
    for col, (h, w) in enumerate(hdrs, 1):
        _hdr(ws, col, h, w)
    ws.set_row_height(1, 26)

    row = 2; i = 0
    for rec, dados in resultado.items():
        if not isinstance(dados, dict) or 'grupos' not in dados.get(str(ano1), dados.get(str(ano2), {})):
            continue
        lbl = 'Shape Completo' if rec == '__shape_completo__' else rec
        for ano_k in [str(ano1), str(ano2)]:
            pai = dados.get(ano_k, {}).get('paisagem', {})
            for sigla, v in pai.items():
                shade = COR_A if i % 2 == 0 else COR_B
                ws.write(row, 1, lbl,                    color=shade)
                ws.write(row, 2, sigla,                  color=shade)
                ws.write(row, 3, UNIDADES.get(sigla,''), color=shade)
                ws.write(row, 4, int(ano_k),             color=shade)
                ws.write(row, 5, v, color=shade,
                         num_fmt='num' if isinstance(v,float) else None)
                row += 1; i += 1
    ws.write(row + 1, 1, CRED)


def _aba_variacoes(wb, resultado, ano1, ano2):
    """
    Tidy: recorte | grupo | metrica | unidade | valor_ano1 | valor_ano2 | delta_abs | delta_pct
    """
    ws   = wb.add_sheet("Variacoes")
    hdrs = [("recorte",30),("grupo",28),("metrica",12),("unidade",10),
            (f"valor_{ano1}",16),(f"valor_{ano2}",16),
            ("delta_abs",16),("delta_pct",12)]
    for col, (h, w) in enumerate(hdrs, 1):
        _hdr(ws, col, h, w)
    ws.set_row_height(1, 26)

    COR_P = "C8E6C9"; COR_N = "FFCCBC"
    row = 2; i = 0
    for rec, dados in resultado.items():
        if not isinstance(dados, dict) or 'grupos' not in dados.get(str(ano1), dados.get(str(ano2), {})):
            continue
        lbl = 'Shape Completo' if rec == '__shape_completo__' else rec
        g1 = dados.get(str(ano1), {}).get('grupos', {})
        g2 = dados.get(str(ano2), {}).get('grupos', {})
        todos_grupos = set(g1) | set(g2)
        for nome_g in sorted(todos_grupos):
            m1 = g1.get(nome_g, {})
            m2 = g2.get(nome_g, {})
            todas_met = set(m1) | set(m2)
            for sigla in sorted(todas_met):
                v1 = m1.get(sigla)
                v2 = m2.get(sigla)
                if v1 is None and v2 is None:
                    continue
                v1 = v1 if v1 is not None else 0.0
                v2 = v2 if v2 is not None else 0.0
                dabs = round(v2 - v1, 4)
                dpct = round((v2-v1)/abs(v1)*100, 2) if v1 != 0 else None
                shade = COR_P if dabs > 0 else (COR_N if dabs < 0 else COR_A)
                ws.write(row, 1, lbl,                    color=shade)
                ws.write(row, 2, nome_g,                 color=shade)
                ws.write(row, 3, sigla,                  color=shade)
                ws.write(row, 4, UNIDADES.get(sigla,''), color=shade)
                ws.write(row, 5, v1,   color=shade, num_fmt='num')
                ws.write(row, 6, v2,   color=shade, num_fmt='num')
                ws.write(row, 7, dabs, color=shade, num_fmt='num')
                ws.write(row, 8,
                         f"{dpct:+.2f}%" if dpct is not None else 'N/D',
                         color=shade)
                row += 1; i += 1
    ws.write(row + 1, 1, CRED)


def exportar(resultado, pasta, ano1, ano2, progresso_fn=None):
    def prog(msg):
        if progresso_fn: progresso_fn(msg)

    prog("  Gerando paisagem.xlsx...")
    wb = XlsxBook()
    _aba_metricas(wb,   resultado, ano1, ano2)
    _aba_paisagem(wb,   resultado, ano1, ano2)
    _aba_variacoes(wb,  resultado, ano1, ano2)

    p = os.path.join(pasta, f"{ano1}_{ano2}_paisagem.xlsx")
    wb.save(p)
    prog(f"  ✓ {os.path.basename(p)}")
    return [p]
