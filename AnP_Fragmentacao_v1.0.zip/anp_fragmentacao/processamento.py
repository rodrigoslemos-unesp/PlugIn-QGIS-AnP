"""
AnP Fragmentação — Processamento de rasters e cálculo de métricas.
"""

import math
import numpy as np
from qgis.core import QgsMessageLog, Qgis
from .legenda import (MAPA_N1, NODATA_VALS, GRUPOS_FRAG,
                      METRICAS_CLASSE_PLS, METRICAS_PAISAGEM_PLS,
                      UNIDADES, agregar_n1)

LOG = 'AnP-Frag'

def log(msg, level=Qgis.Info):
    QgsMessageLog.logMessage(str(msg), LOG, level)


# ── Abertura de raster ────────────────────────────────────────────────────────

def abrir_raster(path):
    from osgeo import gdal
    ds = gdal.Open(path)
    if ds is None:
        raise RuntimeError(f"Não foi possível abrir: {path}")
    gt   = ds.GetGeoTransform()
    proj = ds.GetProjection()
    px_m = abs(gt[1])
    px_ha = (px_m ** 2) / 10000.0
    band = ds.GetRasterBand(1)
    nd   = band.GetNoDataValue()
    arr  = band.ReadAsArray().astype(np.int32)
    ds   = None
    return arr, px_m, px_ha, nd, gt, proj


def detectar_resolucao(path):
    """Retorna resolução espacial em metros."""
    from osgeo import gdal
    ds = gdal.Open(path)
    if ds is None:
        return None
    res = abs(ds.GetGeoTransform()[1])
    ds = None
    return res


def recortar_por_geom(arr, nd, gt, proj, geom, crs_wkt):
    from osgeo import gdal, ogr, osr
    g = geom.Clone()
    if not g.IsValid():
        g = g.MakeValid()
    rows, cols = arr.shape
    env = g.GetEnvelope()
    px0 = max(0, int((env[0]-gt[0])/gt[1]))
    px1 = min(cols, int((env[1]-gt[0])/gt[1])+2)
    py0 = max(0, int((env[3]-gt[3])/gt[5]))
    py1 = min(rows, int((env[2]-gt[3])/gt[5])+2)
    if px0 >= px1 or py0 >= py1:
        raise ValueError("Feição sem sobreposição com o raster.")
    sub  = arr[py0:py1, px0:px1].copy()
    h, w = sub.shape
    gt_s = (gt[0]+px0*gt[1], gt[1], gt[2], gt[3]+py0*gt[5], gt[4], gt[5])
    mem  = gdal.GetDriverByName('MEM')
    mds  = mem.Create('', w, h, 1, gdal.GDT_Byte)
    mds.SetGeoTransform(gt_s); mds.SetProjection(proj)
    mds.GetRasterBand(1).Fill(0)
    vds  = ogr.GetDriverByName('Memory').CreateDataSource('')
    srs  = osr.SpatialReference(); srs.ImportFromWkt(crs_wkt)
    lyr  = vds.CreateLayer('', srs=srs)
    ft   = ogr.Feature(lyr.GetLayerDefn()); ft.SetGeometry(g)
    lyr.CreateFeature(ft)
    gdal.RasterizeLayer(mds, [1], lyr, burn_values=[1])
    mds.FlushCache()
    mask = mds.GetRasterBand(1).ReadAsArray()
    mds = vds = None
    nd_v = int(nd) if nd is not None else -1
    sub[mask == 0] = nd_v
    return sub


# ── Cálculo de métricas ───────────────────────────────────────────────────────

def calcular_nucleo(arr_n1, codigos_n1, px_ha, n_pixels, prog=None):
    """
    Calcula TCA, CORE_MN, NDCA via erosão morfológica binária.
    arr_n1    : array já agregado ao N1
    codigos_n1: lista de códigos N1 a incluir na máscara
    n_pixels  : raio de erosão em pixels
    """
    from scipy.ndimage import binary_erosion, label as nd_label

    mask = np.zeros(arr_n1.shape, dtype=bool)
    for c in codigos_n1:
        mask |= (arr_n1 == c)

    if not np.any(mask):
        return {"TCA": 0.0, "CORE_MN": 0.0, "NDCA": 0}

    r = int(n_pixels)
    y, x = np.ogrid[-r:r+1, -r:r+1]
    struct  = (x*x + y*y <= r*r)
    erodido = binary_erosion(mask, structure=struct)
    n_nuc   = int(np.sum(erodido))

    if n_nuc == 0:
        return {"TCA": 0.0, "CORE_MN": 0.0, "NDCA": 0}

    TCA  = round(n_nuc * px_ha, 4)
    _, n_comp  = nd_label(erodido)
    _, n_frags = nd_label(mask)
    CORE_MN    = round(TCA / max(n_frags, 1), 4)
    return {"TCA": TCA, "CORE_MN": CORE_MN, "NDCA": int(n_comp)}


def calcular_pls_classe(arr_n1, px_m, codigos_n1, prog=None):
    """
    Calcula métricas de classe via PyLandStats.
    Para grupos com múltiplos códigos (ex: Cobertura Natural = [1,10]),
    cria um array sintético onde todos os códigos viram código 1 antes
    de passar ao PyLandStats — assim as classes são tratadas como uma.
    """
    try:
        import pylandstats as pls
    except ImportError:
        return {}

    # Array de trabalho: remapear todos os codigos do grupo para código 1
    arr_pls = np.zeros_like(arr_n1)
    for c in codigos_n1:
        arr_pls[arr_n1 == c] = 1
    # Demais classes: manter com seus valores originais (contexto da paisagem)
    # para que TE/ED sejam calculados corretamente contra os vizinhos reais
    for val in np.unique(arr_n1):
        if val not in codigos_n1 and val > 0 and val != 255:
            arr_pls[arr_n1 == val] = int(val) + 100  # offset para não colidir

    try:
        ls = pls.Landscape(arr_pls, res=(px_m, px_m), nodata=0)
        nomes_pls = [METRICAS_CLASSE_PLS[s] for s in METRICAS_CLASSE_PLS
                     if hasattr(ls, METRICAS_CLASSE_PLS[s])]
        if not nomes_pls:
            return {}

        df = ls.compute_class_metrics_df(metrics=nomes_pls)
        if 1 not in df.index:
            return {}

        row = df.loc[1]
        resultado = {}
        for sigla, nome_pls in METRICAS_CLASSE_PLS.items():
            if nome_pls not in df.columns:
                continue
            v = float(row[nome_pls])
            if math.isnan(v) or math.isinf(v):
                continue
            if sigla in ("CA", "AREA_MN"):
                v = round(v / 10000, 4)   # m² → ha
            elif sigla == "MESH":
                v = round(v / 10000, 4)
            else:
                v = round(v, 4)
            resultado[sigla] = v
        return resultado

    except Exception as e:
        if prog: prog(f"  ⚠ PyLandStats: {e}")
        return {}


def calcular_pls_paisagem(arr_n1, px_m, prog=None):
    """Calcula MESH e LSI para o recorte como um todo."""
    try:
        import pylandstats as pls
    except ImportError:
        return {}

    arr_pls = arr_n1.copy()
    arr_pls[arr_pls < 0] = 0
    arr_pls[arr_pls == 255] = 0

    try:
        ls  = pls.Landscape(arr_pls, res=(px_m, px_m), nodata=0)
        nomes = [v for v in METRICAS_PAISAGEM_PLS.values()
                 if hasattr(ls, v)]
        if not nomes:
            return {}
        df = ls.compute_landscape_metrics_df(metrics=nomes)
        resultado = {}
        for sigla, nome_pls in METRICAS_PAISAGEM_PLS.items():
            if nome_pls not in df.columns:
                continue
            v = float(df[nome_pls].iloc[0])
            if math.isnan(v) or math.isinf(v):
                continue
            if sigla == "MESH":
                v = round(v / 10000, 4)
            else:
                v = round(v, 4)
            resultado[sigla] = v
        return resultado
    except Exception as e:
        if prog: prog(f"  ⚠ PyLandStats (paisagem): {e}")
        return {}


# ── Processamento completo ────────────────────────────────────────────────────

def processar_completo(raster1, raster2, ano1, ano2,
                        n_pixels_borda,
                        grupos_ids=None,
                        mascara_path=None, campo_feicao=None,
                        progresso_fn=None):
    """
    Retorna dict:
    {
      '__shape_completo__': {
          ano1: { 'grupos': {nome: {CA, NP, ...}}, 'paisagem': {MESH, LSI} },
          ano2: { ... }
      },
      'Feição X': { ... },
      '_meta': { px_m, px_ha, gt, proj, arr1_n1, arr2_n1, nd }
    }
    """
    def prog(msg):
        log(msg); progresso_fn and progresso_fn(msg)

    prog(f"Abrindo rasters {ano1} e {ano2}...")
    arr1, px_m, px_ha, nd, gt, proj = abrir_raster(raster1)
    arr2, px_m2, _,    _,  _,  _    = abrir_raster(raster2)

    # Alinhar se dimensões diferentes
    if arr1.shape != arr2.shape:
        r = min(arr1.shape[0], arr2.shape[0])
        c = min(arr1.shape[1], arr2.shape[1])
        prog(f"  ⚠ Dimensões diferentes — alinhando para ({r},{c})")
        arr1 = arr1[:r, :c]
        arr2 = arr2[:r, :c]

    # Usar resolução do raster 1
    dist_m = round(n_pixels_borda * px_m)
    prog(f"Agregando para N1 | Borda: {n_pixels_borda}px = {dist_m}m")

    # Filtrar grupos selecionados pelo usuário
    grupos_ativos = [g for g in GRUPOS_FRAG
                     if grupos_ids is None or g['id'] in grupos_ids]
    if not grupos_ativos:
        grupos_ativos = [g for g in GRUPOS_FRAG if g.get('natural')]
    prog(f"  Grupos: {[g['nome'] for g in grupos_ativos]}")

    arr1_n1 = agregar_n1(arr1)
    arr2_n1 = agregar_n1(arr2)

    resultado = {'_meta': {
        'px_m': px_m, 'px_ha': px_ha, 'gt': gt, 'proj': proj,
        'nd': nd, 'arr1_n1': arr1_n1, 'arr2_n1': arr2_n1,
        'n_pixels': n_pixels_borda, 'dist_m': dist_m,
    }}

    def processar_rec(a1_n1, a2_n1, nome_rec):
        prog(f"  Processando: {nome_rec}...")
        rec = {}
        for ano, arr_n1 in [(str(ano1), a1_n1), (str(ano2), a2_n1)]:
            grupos_res = {}
            for grp in grupos_ativos:
                nome_g  = grp['nome']
                cods_n1 = grp['codigos_n1']
                prog(f"    {ano} | {nome_g}...")
                m_pls = calcular_pls_classe(arr_n1, px_m, cods_n1, prog)
                m_nuc = calcular_nucleo(arr_n1, cods_n1, px_ha,
                                        n_pixels_borda, prog)
                grupos_res[nome_g] = {**m_pls, **m_nuc}
            m_pai = calcular_pls_paisagem(arr_n1, px_m, prog)
            rec[ano] = {'grupos': grupos_res, 'paisagem': m_pai}
        return rec

    resultado['__shape_completo__'] = processar_rec(
        arr1_n1, arr2_n1, 'Shape Completo')

    if mascara_path and campo_feicao:
        from osgeo import ogr
        ds = ogr.Open(mascara_path)
        if ds:
            lyr     = ds.GetLayer(0)
            crs_wkt = lyr.GetSpatialRef().ExportToWkt() \
                      if lyr.GetSpatialRef() else proj
            for feat in lyr:
                nome = str(feat.GetField(campo_feicao))[:40]
                geom = feat.GetGeometryRef()
                if geom is None:
                    continue
                try:
                    s1 = recortar_por_geom(arr1, nd, gt, proj,
                                           geom.Clone(), crs_wkt)
                    s2 = recortar_por_geom(arr2, nd, gt, proj,
                                           geom.Clone(), crs_wkt)
                    s1_n1 = agregar_n1(s1)
                    s2_n1 = agregar_n1(s2)
                    resultado[nome] = processar_rec(s1_n1, s2_n1, nome)
                except Exception as e:
                    prog(f"  ⚠ {nome}: {e}")
            lyr.ResetReading()

    return resultado
