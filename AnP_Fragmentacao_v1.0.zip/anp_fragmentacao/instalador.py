"""AnP — Auto-instalação de dependências."""
import sys, subprocess

DEPS = [
    ('numpy',       'numpy',      'Arrays raster'),
    ('scipy',       'scipy',      'Erosão morfológica (área núcleo)'),
    ('pylandstats', 'pylandstats','Métricas de fragmentação'),
]

def verificar_e_instalar():
    from qgis.core import QgsMessageLog, Qgis
    erros = []
    for pip, imp, desc in DEPS:
        try:
            __import__(imp)
        except ImportError:
            QgsMessageLog.logMessage(f'AnP-Frag: instalando {pip}…', 'AnP', Qgis.Info)
            try:
                subprocess.check_call(
                    [sys.executable, '-m', 'pip', 'install', '--quiet',
                     '--no-warn-script-location', pip],
                    stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
                __import__(imp)
            except Exception as e:
                erros.append(f'{pip}: {e}')
    return erros
