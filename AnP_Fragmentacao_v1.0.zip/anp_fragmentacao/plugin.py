"""AnP — Fragmentação e Conectividade da Paisagem v1.0"""
import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon

class AnPFragmentacaoPlugin:
    def __init__(self, iface):
        self.iface  = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), 'icon.png'))
        self.action = QAction(
            icon,
            'Fragmentação e Conectividade da Paisagem',
            self.iface.mainWindow())
        self.action.setToolTip(
            'AnP — Análise de fragmentação e conectividade (MapBiomas)')
        self.action.triggered.connect(self._abrir)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(
            'AnP \u2013 An\u00e1lise da Paisagem', self.action)

    def unload(self):
        self.iface.removePluginMenu(
            'AnP \u2013 An\u00e1lise da Paisagem', self.action)
        self.iface.removeToolBarIcon(self.action)
        del self.action

    def _abrir(self):
        from .instalador import verificar_e_instalar
        erros = verificar_e_instalar()
        if erros:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(
                self.iface.mainWindow(), 'AnP — Dependências',
                'Algumas bibliotecas não puderam ser instaladas:\n\n'
                + '\n'.join(erros))
        from .dialog import AnPFragmentacaoDialog
        if self.dialog is None:
            self.dialog = AnPFragmentacaoDialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
