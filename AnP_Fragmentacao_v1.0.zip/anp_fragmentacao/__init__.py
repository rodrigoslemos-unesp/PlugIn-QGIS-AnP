# AnP — Análise da Paisagem: Fragmentação e Conectividade
# Versão 1.0
# Prof. Dr. Rodrigo Silva Lemos | DGPA/IGCE — Unesp Rio Claro

def classFactory(iface):
    from .plugin import AnPFragmentacaoPlugin
    return AnPFragmentacaoPlugin(iface)
