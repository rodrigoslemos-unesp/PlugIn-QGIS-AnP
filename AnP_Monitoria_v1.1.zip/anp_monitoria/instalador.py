"""
AnP — Instalador automático de dependências.
Verifica e instala bibliotecas Python necessárias ao carregar o plugin.
"""

import sys
import subprocess


DEPENDENCIAS = [
    # (nome_pip, nome_import, descricao)
    ('numpy',   'numpy',   'Cálculo de arrays raster'),
    ('scipy',   'scipy',   'Operações morfológicas (erosão)'),
]


def _instalar(pkg_pip):
    """Instala um pacote via pip no interpretador Python do QGIS."""
    subprocess.check_call(
        [sys.executable, '-m', 'pip', 'install', '--quiet',
         '--no-warn-script-location', pkg_pip],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE)


def verificar_e_instalar(iface=None):
    """
    Verifica cada dependência e instala se ausente.
    Retorna lista de erros (vazia se tudo OK).
    """
    from qgis.core import QgsMessageLog, Qgis
    erros = []

    for pkg_pip, pkg_import, descricao in DEPENDENCIAS:
        try:
            __import__(pkg_import)
        except ImportError:
            QgsMessageLog.logMessage(
                f'AnP: instalando {pkg_pip} ({descricao})...',
                'AnP', Qgis.Info)
            try:
                _instalar(pkg_pip)
                __import__(pkg_import)
                QgsMessageLog.logMessage(
                    f'AnP: {pkg_pip} instalado com sucesso.',
                    'AnP', Qgis.Info)
            except Exception as e:
                msg = f'Não foi possível instalar {pkg_pip}: {e}'
                QgsMessageLog.logMessage(msg, 'AnP', Qgis.Critical)
                erros.append(msg)

    return erros
