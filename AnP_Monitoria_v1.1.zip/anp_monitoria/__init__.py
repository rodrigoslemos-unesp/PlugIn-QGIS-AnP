# AnP — Análise da Paisagem: Monitoria de Cobertura da Terra
# Versão 1.0
# Prof. Dr. Rodrigo Silva Lemos | DGPA/IGCE — Unesp Rio Claro
# rodrigo.s.lemos@unesp.br

def classFactory(iface):
    from .plugin import AnPMonitoriaPlugin
    return AnPMonitoriaPlugin(iface)
