"""
AnP — Processamento de rasters MapBiomas.
Detecta CRS projetado/geográfico e calcula áreas corretamente.
"""

import numpy as np
from qgis.core import QgsMessageLog, Qgis
from .legenda import (LEGENDA, LEGENDA_NIVEL, GRUPOS, CLASSES_EXCLUIR,
                      categoria_transicao, COLECOES,
                      agregar_nivel, descricao_nivel)

LOG = 'AnP-Monitoria'


def log(msg, level=Qgis.Info):
    QgsMessageLog.logMessage(str(msg), LOG, level)


def detectar_crs(path):
    """
    Verifica se o raster tem CRS projetado (metros) ou geográfico (graus).
    Retorna dict:
      is_projected: bool
      pixel_m2    : área real do pixel em m² (se projetado) ou None
      pixel_ha    : área real em ha (se projetado) ou None
      unidade_crs : 'metro' | 'grau'
    """
    from osgeo import gdal, osr
    ds  = gdal.Open(path)
    if ds is None:
        return {'is_projected': False, 'pixel_m2': None,
                'pixel_ha': None, 'unidade_crs': 'desconhecido'}
    gt  = ds.GetGeoTransform()
    prj = ds.GetProjection()
    ds  = None

    srs = osr.SpatialReference()
    srs.ImportFromWkt(prj)
    is_proj = bool(srs.IsProjected())

    if is_proj:
        px_m  = abs(gt[1])
        px_m2 = px_m ** 2
        px_ha = px_m2 / 10000.0
    else:
        px_m2 = None
        px_ha = None

    return {
        'is_projected': is_proj,
        'pixel_m2'    : px_m2,
        'pixel_ha'    : px_ha,
        'unidade_crs' : 'metro' if is_proj else 'grau',
    }


def area_pixel_ha(crs_info, colecao_nome, unidade_solicitada):
    """
    Retorna (pixel_ha_efetivo, aviso).
    Se não projetado, usa área padrão da coleção e gera aviso.
    """
    if crs_info['is_projected']:
        return crs_info['pixel_ha'], None

    # CRS geográfico → usar área padrão da coleção
    col  = COLECOES.get(colecao_nome, {})
    px_m2 = col.get('px_m2', 900)
    px_ha = px_m2 / 10000.0
    res   = col.get('resolucao_m', 30)
    aviso = (
        f"Raster sem sistema de coordenadas projetadas. "
        f"A área foi calculada usando a área padrão de pixel de {res}m × {res}m "
        f"({px_m2} m² = {px_ha:.4f} ha). "
        f"Os valores em área (ha/km²) são estimativas — "
        f"o percentual é mais confiável para análises não projetadas.")
    return px_ha, aviso


def abrir_raster(path):
    from osgeo import gdal
    ds   = gdal.Open(path)
    if ds is None:
        raise RuntimeError(f"Não foi possível abrir: {path}")
    gt   = ds.GetGeoTransform()
    proj = ds.GetProjection()
    band = ds.GetRasterBand(1)
    nd   = band.GetNoDataValue()
    arr  = band.ReadAsArray().astype(np.int32)
    ds   = None
    return arr, gt, proj, nd


def contar_pixels(arr, nodata):
    excluir = set(CLASSES_EXCLUIR)
    if nodata is not None:
        excluir.add(int(nodata))
    contagem = {}
    for cls in np.unique(arr):
        cls_i = int(cls)
        if cls_i in excluir or cls_i <= 0:
            continue
        n = int(np.sum(arr == cls_i))
        if n > 0:
            contagem[cls_i] = n
    return contagem


def gerar_tabela_cobertura(c1, c2, px_ha, nivel=4):
    """Tabela de cobertura com ha e pct."""
    legenda_n = LEGENDA_NIVEL.get(nivel, LEGENDA)
    todas = sorted(
        k for k in set(c1) | set(c2)
        if k not in CLASSES_EXCLUIR and k > 0)
    tot1 = sum(v for k, v in c1.items()
               if k not in CLASSES_EXCLUIR and k > 0) or 1
    tot2 = sum(v for k, v in c2.items()
               if k not in CLASSES_EXCLUIR and k > 0) or 1

    tabela = []
    for cls in todas:
        n1 = c1.get(cls, 0)
        n2 = c2.get(cls, 0)
        tabela.append({
            'cod'    : cls,
            'nome'   : LEGENDA.get(cls, f'Código {cls}'),
            'grupo'  : GRUPOS.get(cls, 'Outros'),
            'n1'     : n1,
            'n2'     : n2,
            'ha1'    : round(n1 * px_ha, 4),
            'ha2'    : round(n2 * px_ha, 4),
            'pct1'   : round(n1 / tot1, 6),
            'pct2'   : round(n2 / tot2, 6),
        })
    return tabela


def gerar_tabela_transicao(arr1, arr2, nodata, px_ha):
    from collections import Counter
    excluir = set(CLASSES_EXCLUIR)
    if nodata is not None:
        excluir.add(int(nodata))

    mask = (
        (arr1 > 0) & (arr2 > 0) &
        (~np.isin(arr1, list(excluir))) &
        (~np.isin(arr2, list(excluir))))

    pares = Counter(zip(arr1[mask].tolist(), arr2[mask].tolist()))

    tabela = []
    for (o, d), n in sorted(pares.items()):
        if n == 0:
            continue
        tabela.append({
            'cod_orig' : o,
            'nome_orig': LEGENDA.get(o, f'Código {o}'),
            'cod_dest' : d,
            'nome_dest': LEGENDA.get(d, f'Código {d}'),
            'cod_trans': o * 100 + d,
            'categoria': categoria_transicao(o, d),
            'n'        : n,
            'area_ha'  : round(n * px_ha, 4),
        })
    return tabela


def _recortar(arr_full, nd, gt, proj, geom, crs_wkt):
    from osgeo import gdal, ogr, osr
    g = geom.Clone()
    if not g.IsValid():
        g = g.MakeValid()
    rows, cols = arr_full.shape
    env = g.GetEnvelope()
    px0 = max(0, int((env[0] - gt[0]) / gt[1]))
    px1 = min(cols, int((env[1] - gt[0]) / gt[1]) + 2)
    py0 = max(0, int((env[3] - gt[3]) / gt[5]))
    py1 = min(rows, int((env[2] - gt[3]) / gt[5]) + 2)
    if px0 >= px1 or py0 >= py1:
        raise ValueError("Feição sem sobreposição.")
    sub  = arr_full[py0:py1, px0:px1].copy()
    h, w = sub.shape
    gt_s = (gt[0]+px0*gt[1], gt[1], gt[2],
            gt[3]+py0*gt[5], gt[4], gt[5])
    mem  = gdal.GetDriverByName('MEM')
    mds  = mem.Create('', w, h, 1, gdal.GDT_Byte)
    mds.SetGeoTransform(gt_s)
    mds.SetProjection(proj)
    mds.GetRasterBand(1).Fill(0)
    vds  = ogr.GetDriverByName('Memory').CreateDataSource('')
    srs  = osr.SpatialReference()
    srs.ImportFromWkt(crs_wkt)
    lyr  = vds.CreateLayer('', srs=srs)
    ft   = ogr.Feature(lyr.GetLayerDefn())
    ft.SetGeometry(g)
    lyr.CreateFeature(ft)
    gdal.RasterizeLayer(mds, [1], lyr, burn_values=[1])
    mds.FlushCache()
    mask = mds.GetRasterBand(1).ReadAsArray()
    mds = vds = None
    nd_v = int(nd) if nd is not None else -1
    sub[mask == 0] = nd_v
    return sub


def processar_completo(raster1, raster2, ano1, ano2,
                        colecao_nome,
                        nivel_legenda=4,
                        mascara_path=None, campo_feicao=None,
                        progresso_fn=None):
    """
    Fluxo principal. Retorna dict:
    {
      'avisos'              : [lista de avisos CRS],
      '__shape_completo__'  : {tab_cob, tab_trans},
      'Nome Feição'         : {tab_cob, tab_trans},
      ...
    }
    """
    def prog(msg):
        log(msg); progresso_fn and progresso_fn(msg)

    prog(f"Detectando sistema de coordenadas...")
    crs_info = detectar_crs(raster1)
    px_ha, aviso = area_pixel_ha(crs_info, colecao_nome, None)

    avisos = []
    if aviso:
        avisos.append(aviso)
        prog(f"⚠ {aviso}")

    prog(f"Abrindo rasters {ano1} e {ano2}...")
    arr1, gt, proj, nd = abrir_raster(raster1)
    arr2, gt2, _,   _  = abrir_raster(raster2)

    # Alinhar ao menor tamanho comum — rasters MapBiomas podem ter
    # dimensões ligeiramente diferentes entre coleções/anos
    if arr1.shape != arr2.shape:
        rows = min(arr1.shape[0], arr2.shape[0])
        cols = min(arr1.shape[1], arr2.shape[1])
        prog(f"  ⚠ Dimensões diferentes: {arr1.shape} vs {arr2.shape}. "
             f"Alinhando para ({rows},{cols}).")
        arr1 = arr1[:rows, :cols]
        arr2 = arr2[:rows, :cols]

    # Agregar pixels ao nível de legenda solicitado
    prog(f"  Agregando ao {descricao_nivel(nivel_legenda)}...")
    arr1 = agregar_nivel(arr1, nivel_legenda)
    arr2 = agregar_nivel(arr2, nivel_legenda)

    resultado = {'avisos': avisos, '_px_ha': px_ha,
                 '_is_projected': crs_info['is_projected'],
                 '_nivel': nivel_legenda,
                 '_raster_meta': {'arr1': arr1, 'arr2': arr2,
                                  'nd': nd, 'gt': gt, 'proj': proj}}

    def processar_rec(a1, a2, nome):
        prog(f"  Processando: {nome}...")
        c1 = contar_pixels(a1, nd)
        c2 = contar_pixels(a2, nd)
        return {
            'tab_cob'  : gerar_tabela_cobertura(c1, c2, px_ha, nivel_legenda),
            'tab_trans': gerar_tabela_transicao(a1, a2, nd, px_ha),
            '_arr1'    : a1,
            '_arr2'    : a2,
        }

    resultado['__shape_completo__'] = processar_rec(arr1, arr2,
                                                     'Shape Completo')

    if mascara_path and campo_feicao:
        from osgeo import ogr
        ds  = ogr.Open(mascara_path)
        if ds:
            lyr = ds.GetLayer(0)
            crs_wkt = (lyr.GetSpatialRef().ExportToWkt()
                       if lyr.GetSpatialRef() else proj)
            for feat in lyr:
                nome = str(feat.GetField(campo_feicao))[:40]
                geom = feat.GetGeometryRef()
                if geom is None:
                    continue
                try:
                    a1 = _recortar(arr1, nd, gt, proj, geom.Clone(), crs_wkt)
                    a2 = _recortar(arr2, nd, gt, proj, geom.Clone(), crs_wkt)
                    resultado[nome] = processar_rec(a1, a2, nome)
                except Exception as e:
                    prog(f"  ⚠ {nome}: {e}")
            lyr.ResetReading()

    return resultado
