"""
AnP — Análise da Paisagem: Monitoria de Cobertura da Terra
Versão 1.0
Prof. Dr. Rodrigo Silva Lemos | DGPA/IGCE — Unesp Rio Claro
"""

import os
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon


class AnPMonitoriaPlugin:

    def __init__(self, iface):
        self.iface   = iface
        self.action  = None
        self.dialog  = None

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), 'icon.png'))
        self.action = QAction(
            icon,
            'Monitoria de Cobertura da Terra',
            self.iface.mainWindow())
        self.action.setToolTip(
            'AnP — Análise multitemporal de cobertura e uso da terra (MapBiomas)')
        self.action.triggered.connect(self._abrir)
        self.iface.addToolBarIcon(self.action)
        # Aparece em: Complementos → AnP – Análise da Paisagem
        self.iface.addPluginToMenu('AnP – Análise da Paisagem',
                                    self.action)

    def unload(self):
        self.iface.removePluginMenu('AnP – Análise da Paisagem',
                                     self.action)
        self.iface.removeToolBarIcon(self.action)
        del self.action

    def _abrir(self):
        # Verificar dependências na primeira abertura
        from .instalador import verificar_e_instalar
        erros = verificar_e_instalar(self.iface)
        if erros:
            QMessageBox.warning(
                self.iface.mainWindow(),
                'AnP — Dependências ausentes',
                'Algumas bibliotecas não puderam ser instaladas:\n\n' +
                '\n'.join(erros) +
                '\n\nO plugin pode não funcionar corretamente.')

        from .dialog import AnPMonitoriaDialog
        if self.dialog is None:
            self.dialog = AnPMonitoriaDialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
